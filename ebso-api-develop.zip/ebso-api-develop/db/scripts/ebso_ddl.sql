USE ebsodb;
DROP TABLE IF EXISTS  refresh_tokens, action_verifications, cart_items, carts, products, categories, user_role, roles, users CASCADE;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    version BIGINT(11) unsigned NOT NULL DEFAULT 1,
	username VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL,
	password VARCHAR(100) NOT NULL,
	enabled TINYINT NOT NULL DEFAULT 1,
	status VARCHAR(40) NOT NULL,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	middle_name VARCHAR(50) NOT NULL,
	phone_number VARCHAR(40) NOT NULL,
	address_line1 VARCHAR(100) NOT NULL,
	address_line2 VARCHAR(100),
	city VARCHAR(50) NOT NULL,
	state VARCHAR(2),
	zip_code VARCHAR(10),
	country VARCHAR(50) NOT NULL,
	last_login_timestamp DATETIME,
	UNIQUE KEY unique_username (username),
	UNIQUE KEY unique_email (email)
);

CREATE TABLE IF NOT EXISTS roles (
    id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    version BIGINT(11) unsigned NOT NULL DEFAULT 1,
	name VARCHAR(50) NOT NULL,
	display_name VARCHAR(100) NOT NULL,
	UNIQUE KEY (name)
);

CREATE TABLE IF NOT EXISTS user_role (
    user_id BIGINT(11) unsigned NOT NULL,
	role_id BIGINT(11) unsigned NOT NULL,
	PRIMARY KEY (user_id, role_id)
);

ALTER TABLE user_role
    ADD CONSTRAINT fk_user_role_1
        FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE user_role
    ADD CONSTRAINT fk_user_role_2
        FOREIGN KEY (role_id) REFERENCES roles(id);

CREATE TABLE IF NOT EXISTS refresh_tokens (
    id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(400) NOT NULL,
    version BIGINT(11) unsigned NOT NULL DEFAULT 1,
    username VARCHAR(50) NOT NULL,
    start_timestamp DATETIME NOT NULL,
    end_timestamp DATETIME NOT NULL,
    UNIQUE KEY (token)
);

ALTER TABLE refresh_tokens
    ADD CONSTRAINT fk_refresh_tokens_1
        FOREIGN KEY (username) REFERENCES users(username);

CREATE TABLE IF NOT EXISTS action_verifications (id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                           verification_code VARCHAR(12) NOT NULL,
                                           verification_type VARCHAR(40) NOT NULL,
                                           verification_timestamp DATETIME,
                                           username VARCHAR(50) NOT NULL,
                                           start_timestamp DATETIME NOT NULL,
                                           end_timestamp DATETIME NOT NULL,
                                           UNIQUE KEY (verification_code)
);

ALTER TABLE action_verifications
    ADD CONSTRAINT fk_action_verifications_1
        FOREIGN KEY (username) REFERENCES users(username);

CREATE TABLE IF NOT EXISTS categories (
    id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    version BIGINT(11) unsigned NOT NULL DEFAULT 1,
	category_name VARCHAR(50) NOT NULL,
	category_display_name VARCHAR(100) NOT NULL,
	category_photo_url VARCHAR(250),
	parent_id BIGINT(11) unsigned,
	category_type VARCHAR(20)  NOT NULL,
	UNIQUE KEY (name, category_type)
);
ALTER TABLE categories
	ADD CONSTRAINT fk_categories_1
		FOREIGN KEY (parent_id) REFERENCES categories(id)
		    ON DELETE NO ACTION
            ON UPDATE NO ACTION;

CREATE TABLE IF NOT EXISTS products (
    id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    version BIGINT(11) unsigned NOT NULL DEFAULT 1,
	product_name VARCHAR(50) NOT NULL,
	product_display_name VARCHAR(100) NOT NULL,
	product_photo_url VARCHAR(250),
	category_id bigint(11) unsigned NOT NULL,
	merchant_id bigint(11) unsigned NOT NULL,
	price decimal(13,4) not null,
	stock_quantity bigint(11) not null,
	likes bigint(11) NOT NULL DEFAULT 0,
	views bigint(11) NOT NULL DEFAULT 0,
    create_timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_timestamp DATETIME NULL DEFAULT NULL,
	UNIQUE KEY (name,category_id, merchant_id)
);
ALTER TABLE products
	ADD CONSTRAINT fk_products_1
		FOREIGN KEY (category_id) REFERENCES categories(id);

ALTER TABLE products
	ADD CONSTRAINT fk_products_2
		FOREIGN KEY (merchant_id) REFERENCES users(id);

CREATE TABLE carts (
  id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
  version BIGINT(11) unsigned NOT NULL DEFAULT 1,
  user_id BIGINT(11) unsigned NOT NULL,
  status VARCHAR(100) NOT NULL,
  create_timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  update_timestamp DATETIME NULL,
  content TEXT NULL DEFAULT NULL
);

ALTER TABLE carts ADD CONSTRAINT fk_cart_1
    FOREIGN KEY (user_id) REFERENCES users (id)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;


CREATE TABLE cart_items (
  id BIGINT(11) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
  version BIGINT(11) unsigned NOT NULL DEFAULT 1,
  product_id BIGINT(11) unsigned NOT NULL,
  cart_id BIGINT unsigned NOT NULL,
  price decimal(13,2) not null,
  discount decimal(13,2) not null,
  quantity SMALLINT(6) NOT NULL DEFAULT 1,
  create_timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  update_timestamp DATETIME NULL DEFAULT NULL);

ALTER TABLE cart_items ADD CONSTRAINT fk_cart_item_1
    FOREIGN KEY (product_id) REFERENCES products (id)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;

ALTER TABLE cart_items ADD CONSTRAINT fk_cart_item_2
    FOREIGN KEY (cart_id) REFERENCES carts (id)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION;