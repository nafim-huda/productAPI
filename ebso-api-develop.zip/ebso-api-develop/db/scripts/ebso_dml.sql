-- Roles Reference Data
INSERT INTO roles(name, display_name)
VALUES ('ROLE_USER', 'User');

INSERT INTO roles(name, display_name)
VALUES ('ROLE_ADMIN','Administrator');

INSERT INTO roles(name, display_name)
VALUES ('ROLE_HELPDESK', 'Helpdesk');

INSERT INTO roles(name, display_name)
VALUES ('ROLE_MERCHANT', 'Merchant');

INSERT INTO roles(name, display_name)
VALUES ('ROLE_MANAGER', 'Manager');

-- Categories Reference Data
INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING', 'Clothing', NULL, NULL, 'GOODS'); -- Generated id should be 1

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN', 'Men''s Clothing', NULL, 1, 'GOODS'); -- Generated id should be 2

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN', 'Women''s Clothing', NULL, 1, 'GOODS'); -- Generated id should be 3

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN_TSHIRT', 'Men''s T-Shirts', NULL, 2, 'GOODS'); -- Generated id should be 4

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN_TSHIRT', 'Women''s T-Shirts', NULL, 3, 'GOODS'); -- Generated id should be 5

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN_PANTS', 'Men''s Pants', NULL, 2, 'GOODS'); -- Generated id should be 6

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN_PANTS', 'Women''s Pants', NULL, 3, 'GOODS'); -- Generated id should be 7

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN_BELT', 'Belt', NULL, 2, 'GOODS'); -- Generated id should be 8

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN_BELT', 'Belt', NULL, 3, 'GOODS'); -- Generated id should be 9

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN_SHOES', 'Men''s Shoes', NULL, 2, 'GOODS'); -- Generated id should be 10

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN_SHOES', 'Women''s Shoes', NULL, 3, 'GOODS'); -- Generated id should be 11

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN_SHOES_DRESS', 'Men''s Dress Shoes', NULL, 10, 'GOODS'); -- Generated id should be 12

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN_SHOES_DRESS', 'Women''s Dress Shoes', NULL, 11, 'GOODS'); -- Generated id should be 13

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_MEN_SHOES_SNEAKERS', 'Men''s Sneakers', NULL, 10, 'GOODS'); -- Generated id should be 14

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CLOTHING_WOMEN_SHOES_SNEAKERS', 'Women''s Sneakers', NULL, 11, 'GOODS'); -- Generated id should be 15

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('MEN_TIE', 'Men''s Ties', NULL, 2, 'GOODS'); -- Generated id should be 16

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY', 'Jewelry', NULL, NULL, 'GOODS'); -- Generated id should be 17

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN', 'Men''s Jewelry', NULL, 17, 'GOODS'); -- Generated id should be 18

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN', 'Women''s Jewelry', NULL, 17, 'GOODS'); -- Generated id should be 19

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN_WATCH', 'Men''s Watches', NULL, 18, 'GOODS'); -- Generated id should be 20

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN_WATCH', 'Women''s Watches', NULL, 19, 'GOODS'); -- Generated id should be 21

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN_EARRINGS', 'Men''s Earrings', NULL, 18, 'GOODS'); -- Generated id should be 22

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN_EARRINGS', 'Women''s Earrings', NULL, 19, 'GOODS'); -- Generated id should be 23

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN_NECKLACE', 'Men''s Necklaces', NULL, 18, 'GOODS'); -- Generated id should be 24

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN_NECKLACE', 'Women''s Necklaces', NULL, 19, 'GOODS'); -- Generated id should be 25

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN_BRACELET', 'Men''s Bracelets', NULL, 18, 'GOODS'); -- Generated id should be 26

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN_BRACELET', 'Women''s Bracelets', NULL, 19, 'GOODS'); -- Generated id should be 27

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN_RING', 'Men''s Rings', NULL, 18, 'GOODS'); -- Generated id should be 28

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN_RING', 'Women''s Rings', NULL, 19, 'GOODS'); -- Generated id should be 29

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_MEN_OTHER', 'Other Men''s Jewelry', NULL, 18, 'GOODS'); -- Generated id should be 30

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('JEWELRY_WOMEN_OTHER', 'Other Women''s Jewelry', NULL, 19, 'GOODS'); -- Generated id should be 31

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS', 'Electronics', NULL, NULL, 'GOODS'); -- Generated id should be 32

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_TV', 'Television', NULL, 32, 'GOODS'); -- Generated id should be 33

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_COMPUTER', 'Computer', NULL, 32, 'GOODS'); -- Generated id should be 34

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_LAPTOP', 'Laptop', NULL, 34, 'GOODS'); -- Generated id should be 35

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_IPAD', 'iPad', NULL, 32, 'GOODS'); -- Generated id should be 36

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_TABLET', 'Tablet', NULL, 32, 'GOODS'); -- Generated id should be 37

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_CELL_PHONE', 'Cell Phones', NULL, 32, 'GOODS'); -- Generated id should be 38

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_CELL_PHONE_IPHONE', 'iPhone', NULL, 38, 'GOODS'); -- Generated id should be 39

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_CELL_PHONE_SAMSUNG', 'Samsung', NULL, 38, 'GOODS'); -- Generated id should be 40

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('ELECTRONICS_CELL_PHONE_OTHER', 'Other Phone', NULL, 38, 'GOODS'); -- Generated id should be 41

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('APPLIANCES', 'Appliances', NULL, NULL, 'GOODS'); -- Generated id should be 42

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('APPLIANCES_MICROWAVE', 'Microwave', NULL, 42, 'GOODS'); -- Generated id should be 43

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('APPLIANCES_REFRIGERATOR', 'Refrigerator', NULL, 42, 'GOODS'); -- Generated id should be 44

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('APPLIANCES_IRON', 'Iron', NULL, 42, 'GOODS'); -- Generated id should be 45

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('APPLIANCES_OTHER', 'Other Appliances', NULL, 42, 'GOODS'); -- Generated id should be 46

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS', 'Books', NULL, NULL, 'GOODS'); -- Generated id should be 47

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_ENGLISH', 'English Books', NULL, 47, 'GOODS'); -- Generated id should be 48

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_FOREIGN_LANGUAGES', 'Foreign Language Books', NULL, 47, 'GOODS'); -- Generated id should be 49

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_FOREIGN_LANGUAGES_FRENCH', 'French Books', NULL, 49, 'GOODS'); -- Generated id should be 50

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_FOREIGN_LANGUAGES_SPANISH', 'Spanish Books', NULL, 49, 'GOODS'); -- Generated id should be 51

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_FOREIGN_LANGUAGES_CHINESE', 'Chinese Books', NULL, 49, 'GOODS'); -- Generated id should be 52

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_FOREIGN_LANGUAGES_OTHER', 'Other Foreign Language Books', NULL, 49, 'GOODS'); -- Generated id should be 53

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('MATH_BOOKS', 'Math Books', NULL, 47, 'GOODS'); -- Generated id should be 54

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_MATH_CALCULUS', 'Calculus Books', NULL, 54, 'GOODS'); -- Generated id should be 55

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_MATH_LINEAR_ALGEBRA', 'Linear Algebra Books', NULL, 54, 'GOODS'); -- Generated id should be 56

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_MATH_DIFFERENTIAL_EQUATIONS', 'Differential Equations Books', NULL, 54, 'GOODS'); -- Generated id should be 57

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_MATH_OTHER', 'Other Math Books', NULL, 54, 'GOODS'); -- Generated id should be 58

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_SCIENCE', 'Science Books', NULL, 47, 'GOODS'); -- Generated id should be 59

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_SCIENCE_BIOLOGY', 'Biology Books', NULL, 59, 'GOODS'); -- Generated id should be 60

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_SCIENCE_CHEMISTRY', 'Chemistry Books', NULL, 59, 'GOODS'); -- Generated id should be 61

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_SCIENCE_PHYSICS', 'Physics Books', NULL, 59, 'GOODS'); -- Generated id should be 62

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_SCIENCE_OTHER', 'Other Science Books', NULL, 59, 'GOODS'); -- Generated id should be 63

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_BUSINESS', 'Business Books', NULL, 47, 'GOODS'); -- Generated id should be 64

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_BUSINESS_ECONOMICS', 'Economics Books', NULL, 64, 'GOODS'); -- Generated id should be 65

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_BUSINESS_OTHER', 'Other Business Books', NULL, 64, 'GOODS'); -- Generated id should be 66

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_COMPUTER_SCIENCE', 'Computer Science Books', NULL, 47, 'GOODS'); -- Generated id should be 67

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_COMPUTER_SCIENCE_PROGRAMMING', 'Computer Programming', NULL, 67, 'GOODS'); -- Generated id should be 68

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_COMPUTER_SCIENCE_DATABASES', 'Databases', NULL, 67, 'GOODS'); -- Generated id should be 69

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_COMPUTER_SCIENCE_OTHER', 'Other Computer Science Subjects', NULL, 67, 'GOODS'); -- Generated id should be 70

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('BOOKS_OTHER_SUBJECTS', 'Other Subjects Books', NULL, 47, 'GOODS'); -- Generated id should be 71

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS', 'Fitness', NULL, NULL, 'SERVICES'); -- Generated id should be 72

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS_WEIGHT_TRAINING', 'Weight Training', NULL, 72, 'SERVICES'); -- Generated id should be 73

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS_SWIMMING', 'Swimming', NULL, 72, 'SERVICES'); -- Generated id should be 74

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS_CYCLING', 'Cycling', NULL, 72, 'SERVICES'); -- Generated id should be 75

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS_BASKETBALL', 'Basketball', NULL, 72, 'SERVICES'); -- Generated id should be 76

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS_SOCCER', 'Soccer', NULL, 72, 'SERVICES'); -- Generated id should be 77

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('FITNESS_MARTIAL_ARTS', 'Martial Arts', NULL, 72, 'SERVICES'); -- Generated id should be 78

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION', 'Education', NULL, NULL, 'SERVICES'); -- Generated id should be 79

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING', 'Tutoring', NULL, 79, 'SERVICES'); -- Generated id should be 80

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_ENGLISH', 'English Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 81

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_FOREIGN_LANGUAGES', 'Foreign Languages Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 82

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_FOREIGN_LANGUAGES_SPANISH', 'Spanish Tutoring', NULL, 82, 'SERVICES'); -- Generated id should be 83

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_FOREIGN_LANGUAGES_FRENCH', 'French Tutoring', NULL, 82, 'SERVICES'); -- Generated id should be 84

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_FOREIGN_LANGUAGES_CHINESE', 'Chinese Tutoring', NULL, 82, 'SERVICES'); -- Generated id should be 85

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_FOREIGN_LANGUAGES_OTHER', 'Other Foreign Languages Tutoring', NULL, 82, 'SERVICES'); -- Generated id should be 86

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_MATH', 'Math Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 87

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_MATH_CALCULUS', 'Calculus Tutoring', NULL, 87, 'SERVICES'); -- Generated id should be 88

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_MATH_LINEAR_ALGEBRA', 'Linear Algebra Tutoring', NULL, 87, 'SERVICES'); -- Generated id should be 89

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_MATH_DIFFERENTIAL_EQUATIONS', 'Differential Equations', NULL, 87, 'SERVICES'); -- Generated id should be 90

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_MATH_OTHER', 'Other Math Subjects Tutoring', NULL, 87, 'SERVICES'); -- Generated id should be 91

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_SCIENCE', 'Science Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 92

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_SCIENCE_BIOLOGY', 'Biology Tutoring', NULL, 92, 'SERVICES'); -- Generated id should be 93

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_SCIENCE_CHEMISTRY', 'Chemistry Tutoring', NULL, 92, 'SERVICES'); -- Generated id should be 94

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_SCIENCE_PHYSICS', 'Physics Tutoring', NULL, 92, 'SERVICES'); -- Generated id should be 95

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_SCIENCE_OTHER', 'Other Science Subjects Tutoring', NULL, 92, 'SERVICES'); -- Generated id should be 96

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_COMPUTER_SCIENCE', 'Computer Science Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 97

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_COMPUTER_SCIENCE_PROGRAMMING', 'Computer Programming Tutoring', NULL, 97, 'SERVICES'); -- Generated id should be 98

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_COMPUTER_SCIENCE_DATABASES', 'Databases Tutoring', NULL, 97, 'SERVICES'); -- Generated id should be 99

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_COMPUTER_SCIENCE_OTHER', 'Other Computer Science Subjects Tutoring', NULL, 97, 'SERVICES'); -- Generated id should be 100

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_BUSINESS', 'Business Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 101

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_BUSINESS_ECONOMICS', 'Economics Tutoring', NULL, 101, 'SERVICES'); -- Generated id should be 102

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_BUSINESS_OTHER', 'Other Business Subjects Tutoring', NULL, 101, 'SERVICES'); -- Generated id should be 103

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EDUCATION_TUTORING_OTHER', 'Other Subjects Tutoring', NULL, 80, 'SERVICES'); -- Generated id should be 104

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY', 'Photography', NULL, NULL, 'SERVICES'); -- Generated id should be 105

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY_SPORTS', 'Sports Photography', NULL, 105, 'SERVICES'); -- Generated id should be 106

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY_GRADUATION', 'Graduation Photography', NULL, 105, 'SERVICES'); -- Generated id should be 107

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY_PORTRAIT', 'Portrait Photography', NULL, 105, 'SERVICES'); -- Generated id should be 108

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY_WEDDING', 'Wedding Photography', NULL, 105, 'SERVICES'); -- Generated id should be 109

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY_ARCHITECTURE', 'Architecture Photography', NULL, 105, 'SERVICES'); -- Generated id should be 110

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('PHOTOGRAPHY_OTHER', 'Other Photography', NULL, 105, 'SERVICES'); -- Generated id should be 111

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('CATERING', 'Catering', NULL, NULL, 'SERVICES'); -- Generated id should be 112

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('EVENT_PLANNING', 'Event Planning', NULL, NULL, 'SERVICES'); -- Generated id should be 113

INSERT INTO categories(name, display_name, photo_url, parent_id, category_type)
VALUES ('LODGING', 'Lodging', NULL, NULL, 'SERVICES'); -- Generated id should be 114
