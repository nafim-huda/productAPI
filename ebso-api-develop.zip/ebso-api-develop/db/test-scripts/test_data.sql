insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
	values ('EbsoUser1', 'ebsoUser1@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'John', 'Doe', 'Yeah', '111-222-3333', '123 Ebso St', 'Apt 1', 'Washington', 'DC', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
	values ('EbsoUser2', 'ebsoUser2@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Jane', 'Doe', 'Wow', '111-222-3334', '123 Ebso St', 'Apt 1', 'Washington', 'DC', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
	values ('EbsoUser3', 'ebsoUser3@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Michael', 'Java', 'Hmmm', '112-222-3333', '123 Ebso St', 'Apt 2', 'Washington', 'DC', 'United States');


insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
	values ('EbsoUser4', 'ebsoUser4@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Robert', 'Cloud', 'Lol', '113-222-3333', '233 Ebso Rd', 'Suite 200', 'Bethesda', 'MD', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
	values ('EbsoUser5', 'ebsoUser5@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Jennifer', 'Sunny', 'Test', '113-222-3333', '233 Venus Rd', 'Suite 1000', 'Vienna', 'VA', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
values ('EbsoUser6', 'ebsoUser6@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Suzanne', 'Windy', 'SMH', '113-222-3333', '233 Venus Rd', 'Suite 1000', 'Vienna', 'VA', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
values ('EbsoUser7', 'ebsoUser7@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Carlos', 'Shiny', 'WTF', '113-222-3333', '233 Venus Rd', 'Suite 1000', 'Vienna', 'VA', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
values ('EbsoUser8', 'ebsoUser8@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Isiah', 'Bright', 'BRB', '113-222-3333', '233 Venus Rd', 'Suite 1000', 'Vienna', 'VA', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
values ('EbsoUser9', 'ebsoUser9@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Kalalou', 'Gumb', 'Yes', '113-222-3333', '233 Grub Rd', 'Suite 1010', 'Vienna', 'VA', 'United States');

insert into users (username, email, password, enabled, status, first_name, last_name, middle_name, phone_number, address_line1, address_line2, city,state, country)
values ('EbsoUser10', 'ebsoUser10@something.com', '$2b$10$pFdMP/oYqBk24nr5XsfVa.igRv65D1rfA0qTp9qk7kT2QwMmDPcSe', 1, 'ACTIVE', 'Bleef', 'Jerkyl', 'Huh', '113-222-3333', '233 Venus Rd', 'Suite 1000', 'Vienna', 'VA', 'United States');

insert into user_role(user_id, role_id) values (1,1);
insert into user_role(user_id, role_id) values (2,2);
insert into user_role(user_id, role_id) values (3,3);
insert into user_role(user_id, role_id) values (4,4);
insert into user_role(user_id, role_id) values (5,5);
insert into user_role(user_id, role_id) values (6,1);
insert into user_role(user_id, role_id) values (7,1);
insert into user_role(user_id, role_id) values (8,4);
insert into user_role(user_id, role_id) values (9,1);
insert into user_role(user_id, role_id) values (10,1);


insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
    values('AIR_JORDAN_III_SIZE12', 'Air Jordan III - Gotta Be the Shoes - 1988 [Size 12]', 'air_jordan_3.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_IV_SIZE12', 'Air Jordan IV - Taking Flight - 1989 [Size 12]', 'air_jordan_4.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_V_SIZE12', 'Air Jordan V - The Fighter - 1990 [Size 12]', 'air_jordan_5.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_VI_SIZE_12', 'Air Jordan VI - Promised Land - 1991 [Size 12]', 'air_jordan_6.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_VII_SIZE_12', 'Air Jordan VII - Pure Gold - 1992 [Size 12]', 'air_jordan_7.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_VIII_SIZE_12', 'Air Jordan VIII - Strap In - 1993 [Size 12]', 'air_jordan_8.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_IX_SIZE_12', 'Air Jordan IX - Perfect Harmony - 1993 [Size 12]', 'air_jordan_9.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_X_SIZE_12', 'Air Jordan X - The Legacy Continues 1994 [Size 12]', 'air_jordan_10.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XI_SIZE_12', 'Air Jordan XI - Class Act - 1995 [Size 12]', 'air_jordan_11.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XII_SIZE_12', 'Air Jordan XII - The Dynasty Continues - 1996 [Size 12]', 'air_jordan_12.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XIII_SIZE_12', 'Air Jordan XIII - Black Cat Pounces - 1997 [Size 12]', 'air_jordan_13.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XIV_SIZE_12', 'Air Jordan XIV - Race Ready - 1998 [Size 12]', 'air_jordan_14.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XV_SIZE_12', 'Air Jordan XV - Speed of Sound - 1999 [Size 12]', 'air_jordan_15.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XVI_SIZE_12', 'Air Jordan XVI - Marching On - 2001 [Size 12]', 'air_jordan_16.jpgD',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XVII_SIZE_12', 'Air Jordan XVII - Jazzed Up - 2002 [Size 12]', 'air_jordan_17.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XVIII_SIZE_12', 'Air Jordan XVIII - Last Dance - 2003 [Size 12]', 'air_jordan_18.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XIX_SIZE_12', 'Air Jordan XIX - Full Flex - 2004 [Size 12]', 'air_jordan_19.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XX_SIZE_12', 'Air Jordan XX - Living Greatness - 2005 [Size 12]', 'air_jordan_20.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXI_SIZE_12', 'Air Jordan XXI - Performance Luxury DNA - 2006 [Size 12]', 'air_jordan_21.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXII_SIZE_12', 'Air Jordan XXII - Hit the Afterburners - 2007 [Size 12]', 'air_jordan_22.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXIII_SIZE_12', 'Air Jordan XXIII - The Number of Greatness - 2008 [Size 12]', 'air_jordan_23.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_2009_SIZE_12', 'Air Jordan 2009 - Beyond - 2009 [Size 12]', 'air_jordan_24.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_2010_SIZE_12', 'Air Jordan 2010 - Full Speed Ahead - 2010 [Size 12]', 'air_jordan_25.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_2011_SIZE_12', 'Air Jordan 2011 - 2011 [Size 12]', 'air_jordan_26.jpg',14, 8, 175.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_2012_SIZE_12', 'Air Jordan 2012 - Choose Your Flight - 2012 [Size 12]', 'air_jordan_27.jpg',14, 8, 200.00, 10, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXVIII_SIZE_12', 'Air Jordan XXVIII - Dare to Fly - 2013 [Size 12]', 'air_jordan_28.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXIX_SIZE_12', 'Air Jordan XXIX - 2014 [Size 12]', 'air_jordan_29.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXX_SIZE_12', 'Air Jordan XXX - 2016 [Size 12]', 'air_jordan_30.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXXI_SIZE_12', 'Air Jordan XXXI - 2016 [Size 12]', 'air_jordan_31.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXXII_SIZE_12', 'Air Jordan 32 XXXII - 2017 [Size 12]', 'air_jordan_32.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXXIII_SIZE_12', 'Air Jordan 33 XXXIII - 2018 [Size 12]', 'air_jordan_33.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXXIV_SIZE_12', 'Air Jordan 34 XXXIV - 2019 [Size 12]', 'air_jordan_34.jpg',14, 8, 200.00, 100, 0, 0);

insert into products(name, display_name, photo_url, category_id, merchant_id, price, stock_quantity, likes, views)
values('AIR_JORDAN_XXXV_SIZE_12', 'Air Jordan 35 XXXV - 2020 [Size 12]', 'air_jordan_35.jpg',14, 8, 200.00, 100, 0, 0);








