package com.mag7.ebso.ebsoapi.web.security.token.jwt;

import com.mag7.ebso.ebsoapi.entity.RefreshToken;
import com.mag7.ebso.ebsoapi.service.RefreshTokenService;
import com.mag7.ebso.ebsoapi.service.exception.InvalidTokenException;
import com.mag7.ebso.ebsoapi.web.security.token.AppContextHolder;
import com.mag7.ebso.ebsoapi.web.security.token.TokenProvider;
import com.mag7.ebso.ebsoapi.web.security.userdetails.EbsoUserDetails;
import io.jsonwebtoken.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Component
public class JwtTokenProvider implements TokenProvider {
    private static final String BEARER_TOKEN_PREFIX = "Bearer";

    private static final Logger LOGGER = LoggerFactory.getLogger(JwtTokenProvider.class);

    @Value("${com.mag7.ebso.jwt.secret}")
    private String secret;

    @Value("${com.mag7.ebso.token.jwt.expiration}")
    private long jwtTokenExpiration;

    @Value("${com.mag7.ebso.token.refresh.expiration}")
    private long refreshTokenExpiration;

    @Autowired
    RefreshTokenService refreshTokenService;

    @Override
    public String createJwtToken(Authentication authentication) {

        return createToken(authentication, jwtTokenExpiration, false);
    }
    @Override
    public String createRefreshToken(Authentication authentication) {

        return createToken(authentication, refreshTokenExpiration, true);
    }

    @Override
    public JwtDetails refreshTokenIfNecessary(String refreshToken, String jwtToken) {
        //Check in the database to see if the refresh token has expired by checking the end_timestamp value
        //which must be greater than the current time.
        Optional<RefreshToken> refreshTokenEntity = refreshTokenService.getRefreshTokenDetails(refreshToken);
        if (!refreshTokenEntity.isPresent()) {
            throw new InvalidTokenException("The refresh token has expired!");
        }

        Claims refreshTokenClaims = extractClaims(refreshToken, true);
        //Claims has the token value and other user attributes.
        //Claims just contain extra attributes

        //If we are here, the refresh token is valid, but the JWT token could be invalid.

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("The refresh token is still valid");
        }

        Claims jwtTokenClaims = null;

        boolean jwtTokenValid = true;

        try {
            jwtTokenClaims = extractClaims(jwtToken, false);
        } catch (InvalidTokenException ite) {
            jwtTokenValid = false;
        }

        //If the JWT token is valid, check to see if the username extracted from both
        //the JWT token and the username extracted from the refresh token are the same.
        //If they are not the same, it's a security error.  Invalidate the refresh token immediately.
        if (jwtTokenValid) {
            if (!refreshTokenClaims.getSubject().equals(jwtTokenClaims.getSubject())) {
                refreshTokenService.invalidateToken(refreshToken);
                LOGGER.error("User in refresh token is different from user in JWT token!");
                throw new InvalidTokenException("User in refresh token is different from user in JWT token!");
            }
            //If we are here, the JWT token is still valid and there is no need to generate a new one
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("The JWT token is still valid.");
            return new JwtDetails(Optional.of(jwtTokenClaims.getSubject()), Optional.empty());
        }

        //If we are here, the refresh token is valid, but the JWT token is invalid
        //so generate a new one without having to authenticate.  Authentication is required only when the refresh token has expired.
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Generating a new JWT token since the old one is invalid and the refresh token is still valid");
        return new JwtDetails(Optional.of(refreshTokenClaims.getSubject()),
                Optional.of(createToken(refreshTokenClaims, jwtTokenExpiration, false)));
    }

    @Override
    public String getUsername(String token) {
        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody().getSubject();
    }

    public Optional<String> extractFromBearerToken(String bearerToken) {
        if (bearerToken != null && bearerToken.startsWith(BEARER_TOKEN_PREFIX)) {
            return Optional.of(bearerToken.substring(7));
        }
        return Optional.empty();
    }

    private String createToken(Authentication authentication, long tokenExpiration, boolean refresh) {
        EbsoUserDetails userPrincipal = (EbsoUserDetails) authentication.getPrincipal();
        Map<String, Object> claimsMap = new HashMap<>();
        claimsMap.put("firstName", userPrincipal.getFirstName());
        claimsMap.put("lastName", userPrincipal.getLastName());
        claimsMap.put("middleName", userPrincipal.getMiddleName());
        claimsMap.put("status", userPrincipal.getStatus().toString());

        Claims claims = Jwts.claims(claimsMap);
        claims.setSubject(userPrincipal.getUsername());

        return createToken(claims, tokenExpiration, refresh);
    }

    private String createToken(Claims claims, long tokenExpiration, boolean createRefresh) {

        JwtBuilder builder = Jwts.builder().addClaims(claims);

        LocalDateTime startTimestamp = LocalDateTime.now();
        LocalDateTime endTimestamp = startTimestamp.plusMinutes(tokenExpiration);

        String token = builder.setIssuedAt(Date.from(startTimestamp.atZone(ZoneId.systemDefault()).toInstant()))
                .setExpiration(Date.from(endTimestamp.atZone(ZoneId.systemDefault()).toInstant()))
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();

        //If we created a refresh token, then we must store the details in the database.
        //The token record will enable us to perform logout and also help validate the token even if the token itself
        //has not expired. However, the system could have invalidated the token due to a security issue or a logout
        //action by the user.
        if (createRefresh) {
            RefreshToken refreshToken = new RefreshToken(token, claims.getSubject(), startTimestamp, endTimestamp);

            // stores the details in the database
            refreshTokenService.saveToken(refreshToken);
        } else {
            //If we are not creating a refresh token, then we must be creating a JWT token and so,
            //let's add it to ThreadLocal.
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("Adding JWT token to ThreadLocal");

            // Reading the token from the same thread requires doing:  AppContextHolder.getContext().getToken()

            AppContextHolder.getContext().setToken(token);
            // set the token in thread local
        }

        return token;
    }

    public Claims extractClaims(String token, boolean refreshType) {
        try {
            return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
        } catch (SignatureException e) {
            if (refreshType) {
                //For a refresh, it is an error
                LOGGER.error("Invalid JWT signature: {}", e.getMessage());
            } else {
                //For a JWT token, it is a warning since a new JWT token can be generated if the refresh token is valid.
                LOGGER.warn("Invalid JWT signature: {}", e.getMessage()); //For a JWT token, it is just a warning
            }
            throw new InvalidTokenException("Invalid token signature!");
        } catch (MalformedJwtException e) {
            if (refreshType) {
                LOGGER.error("Invalid Refresh token: {}", e.getMessage());
            } else {
                LOGGER.warn("Invalid JWT token: {}", e.getMessage());
            }
            throw new InvalidTokenException("Invalid token!");
        } catch (ExpiredJwtException e) {
            if (refreshType) {
                LOGGER.error("Refresh token has expired: {}", e.getMessage());
            }
            else {
                LOGGER.warn("JWT token has expired: {}", e.getMessage());
            }
            throw new InvalidTokenException("Token has expired!");
        } catch (UnsupportedJwtException e) {
            if (refreshType) {
                LOGGER.error("Refresh token is unsupported: {}", e.getMessage());
            }
            else {
                LOGGER.warn("JWT token is unsupported: {}", e.getMessage());
            }
            throw new InvalidTokenException("Token is unsupported!");
        } catch (IllegalArgumentException e) {
            if (refreshType) {
                LOGGER.error("Refresh claims string is empty: {}", e.getMessage());
            }
            else {
                LOGGER.warn("JWT claims string is empty: {}", e.getMessage());
            }
            throw new InvalidTokenException("Claims must not be empty!");
        }
    }

}
