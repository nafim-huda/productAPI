package com.mag7.ebso.ebsoapi.entity;

public enum CartStatus {
    SHOPPING,
    IN_CHECKOUT
}
