package com.mag7.ebso.ebsoapi.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class UserDTO implements Serializable {

    private static final long serialVersionUID = -3324372713581435281L;

    private Long id;
    private Long version;
    private String username;
    private String email;
    private NameDTO name;
    private AddressDTO address;
    private String phoneNumber;
    private LocalDateTime lastLoginTimestamp;
    private String status;
    private Set<RoleDTO> roles = new HashSet<>();

    public UserDTO() {
    }

    public UserDTO(String username,
                   NameDTO name,
                   String status,
                   Set<RoleDTO> roles) {
        this.username = username;
        this.name = name;
        this.status = status;

        if (roles != null && !roles.isEmpty()) {
            this.roles.addAll(roles);
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public NameDTO getName() {
        return name;
    }

    public void setName(NameDTO name) {
        this.name = name;
    }

    public AddressDTO getAddress() {
        return address;
    }

    public void setAddress(AddressDTO address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalDateTime getLastLoginTimestamp() {
        return lastLoginTimestamp;
    }

    public void setLastLoginTimestamp(LocalDateTime lastLoginTimestamp) {
        this.lastLoginTimestamp = lastLoginTimestamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Set<RoleDTO> getRoles() {
        return roles;
    }

    public void setRoles(Set<RoleDTO> roles) {
        if (roles != null && !roles.isEmpty()) {
            this.roles.addAll(roles);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserDTO)) return false;
        UserDTO userDTO = (UserDTO) o;
        return getUsername().equals(userDTO.getUsername()) ||
                getEmail().equals(userDTO.getEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getUsername(), getEmail());
    }


    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", version=" + version +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", name=" + name +
                ", address=" + address +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", lastLoginTimestamp=" + lastLoginTimestamp +
                ", status='" + status + '\'' +
                ", roles=" + roles +
                '}';
    }
}
