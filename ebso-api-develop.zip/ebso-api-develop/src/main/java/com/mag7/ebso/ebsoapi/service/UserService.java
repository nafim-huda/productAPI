package com.mag7.ebso.ebsoapi.service;

import com.mag7.ebso.ebsoapi.entity.ActionVerification;
import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.service.support.UserCriteria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import javax.mail.MessagingException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;

public interface UserService {
    public Optional<User> getUser(Long id);
    public Optional<User> getUser(String username);
    public void registerUser(User user) throws IOException, MessagingException;

    public Page<User> getUsers(UserCriteria userCriteria,
                               Pageable pageRequest);

    public LocalDateTime updateLastLoginTimestamp(String username);

    public void confirmRegistration(ActionVerification verification);

    public void updateRefreshToken(User user);

    public void activateUser(User user);
    public void suspendUser(User user);
    public void reinstateUser(User user);
    public void resetPassword(User user);

}
