package com.mag7.ebso.ebsoapi.repository;

import com.mag7.ebso.ebsoapi.entity.Cart;
import com.mag7.ebso.ebsoapi.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    //This may not be necessary since cart will be eager-fetched, not lazy-fetched
    public List<CartItem> findByCart(Cart cart);
}
