package com.mag7.ebso.ebsoapi.entity;


import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table( name = "categories",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"name", "category_type"})
        })
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private Long version;

    @NotBlank
    @Size(max = 20)
    private String category_name;

    @NotBlank
    @Size(max = 100)
    private String category_display_name;

    @NotBlank
    @Size(max = 250)
    private String category_photoUrl;

    @NotBlank
    @Enumerated(EnumType.STRING)
    @Column(name="category_type", length = 20)
    private CategoryType categoryType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Category parent;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Category> children = new HashSet<>();

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Product> products = new HashSet<>();

    public Category() {
    }

    public Category(Long id, @NotBlank @Size(max = 20) String category_name, @NotBlank @Size(max = 20) String displayName,
                    @NotBlank @Size(max = 50) String photoUrl, @NotBlank CategoryType categoryType, Category parent) {
        this.id = id;
        this.category_name = category_name;
        this.category_display_name = displayName;
        this.category_photoUrl = photoUrl;
        this.categoryType = categoryType;
        this.parent = parent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_display_name() {
        return category_display_name;
    }

    public void setCategory_display_name(String display_name) {
        this.category_display_name = display_name;
    }

    public String getCategory_photoUrl() {
        return category_photoUrl;
    }

    public void setCategory_photoUrl(String photo_url) {
        this.category_photoUrl = photo_url;
    }

    public CategoryType getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(CategoryType categoryType) {
        this.categoryType = categoryType;
    }

    public Category getParent() {
        return parent;
    }

    public void setParent(Category parent) {
        this.parent = parent;
    }

    public Set<Category> getChildren() {
        return children;
    }

    public void setChildren(Set<Category> children) {
        this.children = children;
    }

    public Set<Product> getProducts() {
        return products;
    }

    public void setProducts(Set<Product> products) {
        this.products = products;
    }
}
