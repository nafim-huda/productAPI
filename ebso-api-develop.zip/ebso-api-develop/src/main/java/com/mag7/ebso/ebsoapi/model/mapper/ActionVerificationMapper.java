package com.mag7.ebso.ebsoapi.model.mapper;


import com.mag7.ebso.ebsoapi.entity.ActionVerification;
import com.mag7.ebso.ebsoapi.model.ActionVerificationDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ActionVerificationMapper {
    ActionVerificationDTO toActionVerificationDTO(ActionVerification actionVerification);
    ActionVerification toActionVerification(ActionVerificationDTO actionVerificationDTO);
}
