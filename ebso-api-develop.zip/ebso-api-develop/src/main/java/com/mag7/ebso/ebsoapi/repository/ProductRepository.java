package com.mag7.ebso.ebsoapi.repository;

import com.mag7.ebso.ebsoapi.entity.Category;
import com.mag7.ebso.ebsoapi.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long>, JpaSpecificationExecutor<Product> {


    Page<Product> findAll(Pageable pageRequest);
    Page<Product> findByDisplayNameContaining(String displayName, Pageable pageRequest);
    Page<Product> findByCategory(Category category, Pageable pageRequest);
}
