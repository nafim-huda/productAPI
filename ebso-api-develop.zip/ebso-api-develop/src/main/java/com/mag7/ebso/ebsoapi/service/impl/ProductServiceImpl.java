package com.mag7.ebso.ebsoapi.service.impl;

import com.mag7.ebso.ebsoapi.entity.Category;
import com.mag7.ebso.ebsoapi.entity.Product;
import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.repository.CategoryRepository;
import com.mag7.ebso.ebsoapi.repository.ProductRepository;
import com.mag7.ebso.ebsoapi.repository.support.EntitySpecification;
import com.mag7.ebso.ebsoapi.repository.support.QueryCondition;
import com.mag7.ebso.ebsoapi.repository.support.QueryOperator;
import com.mag7.ebso.ebsoapi.service.ProductService;
import com.mag7.ebso.ebsoapi.service.support.ProductCriteria;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductServiceImpl.class);

    @Autowired
    ProductRepository productRepository;

    @Autowired
    CategoryRepository categoryRepository;

    @Override
    public Optional<Product> getProduct(Long id) {
        return productRepository.findById(id);
    }


    @Override
    public Page<Product> getProducts(ProductCriteria productCriteria,
                                     Pageable pageRequest) {

        EntitySpecification<Product> specification = new EntitySpecification<Product>();
        QueryCondition condition = null;
        if (productCriteria.getCategoryId().isPresent()) {
            Optional<Category> optionalCategory = categoryRepository.findById(productCriteria.getCategoryId().get());
            if (optionalCategory.isPresent()) {
                condition = new QueryCondition("category", new Object[]{optionalCategory.get()}, QueryOperator.EQUAL);
                specification.add(condition);
            } else {
                //TODO:  What to do when the category id is invalid:  Disregard it or throw exception
            }
        }
        if (productCriteria.getProduct_display_name().isPresent()) {
            condition = new QueryCondition("displayName", new String[] {productCriteria.getProduct_display_name().get()}, QueryOperator.MATCH);
            specification.add(condition);
        }
        if (productCriteria.getMinimumPrice().isPresent()) {
            condition = new QueryCondition("price", new BigDecimal[] {productCriteria.getMinimumPrice().get()}, QueryOperator.GREATER_THAN_EQUAL);
            specification.add(condition);
        }

        if (productCriteria.getMaximumPrice().isPresent()) {
            condition = new QueryCondition("price", new BigDecimal[] {productCriteria.getMaximumPrice().get()}, QueryOperator.LESS_THAN_EQUAL);
            specification.add(condition);
        }

        if (productCriteria.getMerchantId().isPresent()) {
            User merchant = new User();
            merchant.setId(productCriteria.getMerchantId().get());
            condition = new QueryCondition("merchant", new Object[] {merchant}, QueryOperator.EQUAL);
            specification.add(condition);
        }

        if (!specification.isEmpty()) {
            return productRepository.findAll(specification, pageRequest);
        }

        return productRepository.findAll(pageRequest);

    }

}
