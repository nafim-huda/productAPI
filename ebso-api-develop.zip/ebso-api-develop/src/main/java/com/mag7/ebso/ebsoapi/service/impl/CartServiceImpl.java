package com.mag7.ebso.ebsoapi.service.impl;

import com.mag7.ebso.ebsoapi.entity.*;
import com.mag7.ebso.ebsoapi.repository.CartItemRepository;
import com.mag7.ebso.ebsoapi.repository.CartRepository;
import com.mag7.ebso.ebsoapi.repository.ProductRepository;
import com.mag7.ebso.ebsoapi.repository.UserRepository;
import com.mag7.ebso.ebsoapi.service.CartService;
import com.mag7.ebso.ebsoapi.service.exception.ServiceException;
import com.mag7.ebso.ebsoapi.util.EbsoUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

// Not done yet
@Service
public class CartServiceImpl implements CartService {
    @Autowired
    CartRepository cartRepository;

    @Autowired
    CartItemRepository cartItemRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    UserRepository userRepository;

    @Override
    public Cart createCart(String username) {
        return null;
    }

    @Override
    public Optional<Cart> getUserCart(String username) {
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isPresent()) {
            return cartRepository.findByUser(user.get());
        }

        return Optional.empty();
    }

    @Override
    public Cart addItem(CartItem item) {
        Cart userCart = null;
        Optional<Cart> cart = cartRepository.findByUser(EbsoUtils.getSimpleUserEntity());

        if (!cart.isPresent())  {
            //If cart does not exist, create a new cart

            //User user = userRepository.findByUsername(EbsoUtils.getUserDetails().getUsername()).get();
            User user = new User();
            user.setId(EbsoUtils.getUserDetails().getId());

            userCart = new Cart();
            userCart.setUser(user);
            userCart.setStatus(CartStatus.SHOPPING);
            cartRepository.save(userCart);
        } else {
            userCart = cart.get();
        }

        Optional<Product> optionalProduct =  productRepository.findById(item.getProduct().getId());
        Product product = null;
        if (optionalProduct.isPresent()) {
            product = optionalProduct.get();
            int stockQuantity = product.getStockQuantity();
            if (stockQuantity == 0)
                throw new ServiceException("Product " + product.getProduct_display_name() + " is currently out of stock!");
            else if ((stockQuantity - item.getQuantity()) < 0 )
                throw new ServiceException("For product " + product.getProduct_display_name() + ", there are only " + stockQuantity + " left in stock!");
            else {
                CartItem cartItem = new CartItem();
                cartItem.setCart(userCart);
                cartItem.setProduct(product);
                cartItem.setQuantity(item.getQuantity());

                //Team:  Should we update product's stock quantity?  Maybe not, since this is not a processed order.
                //product.setStockQuantity(product.getStockQuantity() - cartItem.getQuantity());
                //productRepository.save(product);

                //Save cart item
                //This will throw Spring Framework's ObjectOptimisticLockingFailureException if there was a change to product
                cartItemRepository.save(cartItem);
            }
        }

        return userCart;
    }

    @Override
    public Cart updateItem(CartItem item) {
        cartItemRepository.save(item);
        return cartRepository.findByUser(EbsoUtils.getSimpleUserEntity()).get();
    }

    @Override
    public Cart removeItem(CartItem cartItem) {
        cartItemRepository.delete(cartItem);

        return cartRepository.findByUser(EbsoUtils.getSimpleUserEntity()).get();
    }
}
