package com.mag7.ebso.ebsoapi.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

public class AuthResponseDTO implements Serializable {
    private static final long serialVersionUID = -5874778595732132027L;

    private String username;
    private String firstName;
    private String lastName;
    private String middleName;
    private String status;
    private LocalDateTime lastLoginTimestamp;
    private Set<String> roles = new HashSet<>();


    public AuthResponseDTO() {
    }

    public AuthResponseDTO(String username,
                           String firstName,
                           String lastName,
                           String middleName,
                           String status,
                           LocalDateTime lastLoginTimestamp,
                           Set<String> roles) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.status = status;
        this.lastLoginTimestamp = lastLoginTimestamp;

        if (roles != null && !roles.isEmpty()) {
            this.roles.addAll(roles);
        }
    }

    public String getUsername() {
        return username;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getLastLoginTimestamp() {
        return lastLoginTimestamp;
    }

    public Set<String> getRoles() {
        return roles;
    }

    @Override
    public String toString() {
        return "AuthResponseDTO{" +
                "username='" + username + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", status='" + status + '\'' +
                ", lastLoginTimestamp=" + lastLoginTimestamp +
                ", roles=" + roles +
                '}';
    }
}
