package com.mag7.ebso.ebsoapi.entity;

public enum UserStatus {
    PENDING,
    ACTIVE,
    SUSPENDED,
    DISABLED
}
