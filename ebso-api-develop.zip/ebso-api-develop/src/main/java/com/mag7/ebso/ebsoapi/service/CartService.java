package com.mag7.ebso.ebsoapi.service;

import com.mag7.ebso.ebsoapi.entity.Cart;
import com.mag7.ebso.ebsoapi.entity.CartItem;

import java.util.Optional;

public interface CartService {
    public Cart createCart(String username);
    public Optional<Cart> getUserCart(String username);
    public Cart addItem(CartItem item);
    public Cart updateItem(CartItem item);
    public Cart removeItem(CartItem item);
}
