package com.mag7.ebso.ebsoapi.repository;

import com.mag7.ebso.ebsoapi.entity.RefreshToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
    public Optional<RefreshToken> findByUsernameAndEndTimestampGreaterThan(String username, LocalDateTime endTimestamp);
    public Optional<RefreshToken> findByTokenAndEndTimestampGreaterThan(String token, LocalDateTime endTimestamp);
}
