package com.mag7.ebso.ebsoapi.entity;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Table(	name = "action_verifications")
//        uniqueConstraints = {
//                @UniqueConstraint(columnNames = "verification_code")
//        })
public class ActionVerification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(max = 12)
    private String verificationCode;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private ActionVerificationType verificationType;

    @NotBlank
    @Size(max = 50)
    private String username;

    private LocalDateTime verificationTimestamp;

    private LocalDateTime startTimestamp;

    private LocalDateTime endTimestamp;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public ActionVerificationType getVerificationType() {
        return verificationType;
    }

    public void setVerificationType(ActionVerificationType verificationType) {
        this.verificationType = verificationType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LocalDateTime getVerificationTimestamp() {
        return verificationTimestamp;
    }

    public void setVerificationTimestamp(LocalDateTime verificationTimestamp) {
        this.verificationTimestamp = verificationTimestamp;
    }

    public LocalDateTime getStartTimestamp() {
        return startTimestamp;
    }

    public void setStartTimestamp(LocalDateTime startTimestamp) {
        this.startTimestamp = startTimestamp;
    }

    public LocalDateTime getEndTimestamp() {
        return endTimestamp;
    }

    public void setEndTimestamp(LocalDateTime endTimestamp) {
        this.endTimestamp = endTimestamp;
    }

    @Override
    public String toString() {
        return "ActionVerification{" +
                "id=" + id +
                ", verificationCode='" + verificationCode + '\'' +
                ", verificationType=" + verificationType +
                ", username='" + username + '\'' +
                ", verificationTimestamp=" + verificationTimestamp +
                ", startTimestamp=" + startTimestamp +
                ", endTimestamp=" + endTimestamp +
                '}';
    }
}
