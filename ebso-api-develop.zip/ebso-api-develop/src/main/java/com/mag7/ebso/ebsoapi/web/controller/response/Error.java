package com.mag7.ebso.ebsoapi.web.controller.response;

import java.io.Serializable;

public class Error implements Serializable {
    private static final long serialVersionUID = 2735893862912947628L;

    private String code;
    private String message;

    public Error(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "Error{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
