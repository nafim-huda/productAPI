package com.mag7.ebso.ebsoapi.service.exception;

public class InvalidTokenException extends ServiceException {
    public InvalidTokenException() {
        super();
    }

    public InvalidTokenException(String message) {
        super(message);
    }
    public InvalidTokenException(String errorCode, String message) {
        super(errorCode, message);
    }

    public InvalidTokenException(String errorCode, String message, Throwable cause) {
        super(message, message, cause);
    }

}
