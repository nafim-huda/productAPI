package com.mag7.ebso.ebsoapi.web.security.token;

import org.springframework.util.Assert;

public class AppContextHolder {
    private static final ThreadLocal<AppContext> contextHolder = new ThreadLocal<>();

    public static void clearContext() {
        // Removes context from ThreadLocal
        contextHolder.remove();
    }

    public static AppContext getContext() {
        // Get the context which includes our token from ThreadLocal
        AppContext ctx = contextHolder.get();
        if (ctx == null) {
            ctx = createEmptyContext();
            contextHolder.set(ctx);
        }
        return ctx;
    }

    public static void setContext(AppContext context) {
        // Add the context to ThreadLocal
        Assert.notNull(context, "Only non-null TokenContext instances are permitted");
        contextHolder.set(context);
    }

    public static AppContext createEmptyContext() {
        // Prevents NullPointerException when you call TokenContextHolder.getContext().getToken().
        // While token may be null, the context will not be null.  It might be empty.
        return new AppContextImpl();
    }
}
