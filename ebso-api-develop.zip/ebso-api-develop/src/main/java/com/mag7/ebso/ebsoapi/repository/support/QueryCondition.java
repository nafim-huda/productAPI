package com.mag7.ebso.ebsoapi.repository.support;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

public class QueryCondition implements Serializable {
    private static final long serialVersionUID = 4321309124883518138L;

    private String key;
    private Object[] values;
    private QueryOperator operator;


    public QueryCondition(String key, Object[] values, QueryOperator operator) {
        this.key = key;
        this.values = new Object[values.length];
        for (int i = 0; i < values.length; i++) {
            this.values[i] = values[i];
        }

        this.operator = operator;
    }

    public String getKey() {
        return key;
    }

    public Object[] getValues() {
        return values;
    }

    public QueryOperator getOperator() {
        return operator;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof QueryCondition)) return false;
        QueryCondition that = (QueryCondition) o;
        return getKey().equals(that.getKey()) &&
                Arrays.equals(getValues(), that.getValues()) &&
                getOperator() == that.getOperator();
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(getKey(), getOperator());
        result = 31 * result + Arrays.hashCode(getValues());
        return result;
    }

    @Override
    public String toString() {
        return "QueryCondition{" +
                "key='" + key + '\'' +
                ", values=" + Arrays.toString(values) +
                ", operator=" + operator +
                '}';
    }
}
