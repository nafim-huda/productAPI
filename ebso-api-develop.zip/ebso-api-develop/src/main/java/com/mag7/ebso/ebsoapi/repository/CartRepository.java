package com.mag7.ebso.ebsoapi.repository;

import com.mag7.ebso.ebsoapi.entity.Cart;
import com.mag7.ebso.ebsoapi.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
    public Optional<Cart> findByUser(User user);

}
