package com.mag7.ebso.ebsoapi.web.security.token;

import java.io.Serializable;

public interface AppContext extends Serializable {
    public String getToken();
    public void setToken(String token);
}
