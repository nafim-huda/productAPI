package com.mag7.ebso.ebsoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbsoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbsoApiApplication.class, args);
	}

}