package com.mag7.ebso.ebsoapi.model;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;

public class SignInDTO implements Serializable {
    private static final long serialVersionUID = -7575355069328882382L;

    @NotBlank
    private String username;

    @NotBlank
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SignInDTO)) return false;
        SignInDTO signInDTO = (SignInDTO) o;
        return getUsername().equals(signInDTO.getUsername()) &&
                getPassword().equals(signInDTO.getPassword());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUsername(), getPassword());
    }

    @Override
    public String toString() {
        return "SignInDTO{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
