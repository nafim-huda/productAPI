package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.entity.Name;
import com.mag7.ebso.ebsoapi.model.NameDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface NameMapper {
    NameDTO toNameDTO(Name name);
    Name toName(NameDTO nameDTO);
}
