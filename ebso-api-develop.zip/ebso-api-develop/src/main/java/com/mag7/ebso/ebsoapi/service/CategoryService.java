package com.mag7.ebso.ebsoapi.service;

import com.mag7.ebso.ebsoapi.entity.Category;

import java.util.List;
import java.util.Optional;

public interface CategoryService {
    public List<Category> getMainCategories();

    public Optional<Category> getCategory(Long id);

}
