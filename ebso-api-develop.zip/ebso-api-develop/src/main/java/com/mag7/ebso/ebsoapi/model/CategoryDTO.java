package com.mag7.ebso.ebsoapi.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CategoryDTO implements Serializable {
    private static final long serialVersionUID = 3695010705645929209L;

    private Long id;
    private Long version;
    private String category_name;
    private String category_display_name;
    private String category_photoUrl;
    private String categoryType;

    private List<CategoryDTO> children = new ArrayList();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_display_name() {
        return category_display_name;
    }

    public void setCategory_display_name(String category_display_name) {
        this.category_display_name = category_display_name;
    }

    public String getCategory_photoUrl() {
        return category_photoUrl;
    }

    public void setCategory_photoUrl(String category_photoUrl) {
        this.category_photoUrl = category_photoUrl;
    }

    public String getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(String categoryType) {
        this.categoryType = categoryType;
    }

    public List<CategoryDTO> getChildren() {
        return children;
    }

    public void setChildren(List<CategoryDTO> children) {
        if (children != null && !children.isEmpty())
            this.children = children;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CategoryDTO)) return false;
        CategoryDTO that = (CategoryDTO) o;
        return getCategory_name().equals(that.getCategory_name());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCategory_name());
    }

    @Override
    public String toString() {
        return "CategoryDTO{" +
                "id=" + id +
                ", version=" + version +
                ", name='" + category_name + '\'' +
                ", displayName='" + category_display_name + '\'' +
                ", photoUrl='" + category_photoUrl + '\'' +
                ", categoryType='" + categoryType + '\'' +
                ", children=" + children +
                '}';
    }
}
