package com.mag7.ebso.ebsoapi.service;

import com.mag7.ebso.ebsoapi.entity.Product;
import com.mag7.ebso.ebsoapi.service.support.ProductCriteria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.Optional;

public interface ProductService {
    public Optional<Product> getProduct(Long id);
    // retrieves the product based on the id passed

    public Page<Product> getProducts(ProductCriteria productCriteria,
                                     Pageable pageRequest);


   /* public Page<Product> getProducts(Optional<Long> categoryId,
                                     Optional<String> displayName,
                                     Optional<BigDecimal> minimumPrice,
                                     Optional<BigDecimal> maximumPrice,
                                     Pageable pageRequest); */
    // category id , the display name of the category, the minimum & maximum price
    // Pageable: Page number, size of the page (number if categories on the page),
    // & the sort info (properties to be sorted and the order in which each property should be sorted)



}
