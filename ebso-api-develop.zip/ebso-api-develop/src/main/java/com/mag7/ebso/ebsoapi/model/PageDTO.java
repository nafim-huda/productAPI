package com.mag7.ebso.ebsoapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PageDTO<T> implements Serializable {

    private static final long serialVersionUID = 9083498550142434864L;

    private List<T> content = new ArrayList<>();
    private long totalElements;
    private int size;
    private int number;

    private List<SortPropertyDTO> sortProperties = new ArrayList<>();

    public PageDTO(List<T> content,
                   long totalElements,
                   int size,
                   int number,
                   List<SortPropertyDTO> sortProperties) {

        if (content != null && !content.isEmpty()) {
            this.content = content;
        }

        this.totalElements = totalElements;
        this.size = size;
        this.number = number;

        if (sortProperties != null && !sortProperties.isEmpty()) {
            this.sortProperties = sortProperties;
        }
    }

    public List<T> getContent() {
        return content;
    }

    public long getTotalElements() {
        return totalElements;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getNumber() {
        return number;
    }

    public int getNumberOfElements() {
        return content.size();
    }

    public int getTotalPages() {
        return getSize() == 0 ? 1 : (int) Math.ceil((double) totalElements / (double) getSize());
    }

    @JsonProperty("hasNext")
    public boolean hasNext() {
        return getNumber() + 1 < getTotalPages();
    }

    @JsonProperty("hasPrevious")
    public boolean hasPrevious() {
        return getNumber() > 0;
    }

    public boolean isFirst() {
        return !hasPrevious();
    }

    public boolean isLast() {
        return !hasNext();
    }

    public List<SortPropertyDTO> getSortProperties() {
        return sortProperties;
    }

    public boolean isEmpty() {
        return content.isEmpty();
    }

    @Override
    public String toString() {
        return "PageDTO{" +
                "content=" + content +
                ", totalElements=" + totalElements +
                ", size=" + size +
                ", number=" + number +
                ", sortProperties=" + sortProperties +
                '}';
    }
}
