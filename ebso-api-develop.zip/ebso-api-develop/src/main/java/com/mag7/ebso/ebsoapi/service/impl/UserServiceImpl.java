package com.mag7.ebso.ebsoapi.service.impl;

import com.mag7.ebso.ebsoapi.entity.*;
import com.mag7.ebso.ebsoapi.repository.ActionVerificationRepository;
import com.mag7.ebso.ebsoapi.repository.RoleRepository;
import com.mag7.ebso.ebsoapi.repository.UserRepository;
import com.mag7.ebso.ebsoapi.repository.support.EntitySpecification;
import com.mag7.ebso.ebsoapi.service.EmailService;
import com.mag7.ebso.ebsoapi.service.UserService;
import com.mag7.ebso.ebsoapi.service.exception.InvalidVerificationCodeException;
import com.mag7.ebso.ebsoapi.service.exception.ServiceException;
import com.mag7.ebso.ebsoapi.service.support.UserCriteria;
import com.mag7.ebso.ebsoapi.util.IdGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    EmailService emailService;

    @Autowired
    IdGenerator idGenerator;

    @Autowired
    ActionVerificationRepository actionVerificationRepository;

    UserRepository userRepository;
    RoleRepository roleRepository;

    Map<RoleName, Role> roleCache;

    //This is using construction injection - Spring will automatically inject the dependencies
    public UserServiceImpl(UserRepository userRepository, RoleRepository roleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;

        List<Role> roles = roleRepository.findAll();
        roleCache = roles.stream()
                .collect(Collectors.toMap(Role::getName, role -> role));

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("roleCache:  {}", roleCache);
        }

    }

    @Override
    public Optional<User> getUser(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public Optional<User> getUser(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public void registerUser(User user) throws IOException, MessagingException {
        if (userRepository.existsByUsername(user.getUsername())) {
            // Checks if the username passed is already stored in the database (this username has already been used with an existing account)
            throw new ServiceException("Username " + user.getUsername() + " is already taken!");
        }

        if (userRepository.existsByEmail(user.getEmail())) {
            // Checks if the email is already in the database (this email has already been used with an existing account)
            throw new ServiceException("There already exists an account with email address " + user.getEmail());
        }

        //Make copy of the roles passed in and check whether they exist in the database
        //before assigning them to the user.
        Set<Role> requestedRoles = user.getRoles().stream().collect(Collectors.toSet());

        //Clear roles in order to assign only valid roles.
        user.getRoles().clear();


        if (requestedRoles.isEmpty()) {
            // If the role is empty, set it user as default otherwise throw an exception
            Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
                    .orElseThrow(() -> new ServiceException("Role " + RoleName.ROLE_USER.toString() + " was not found."));
            user.getRoles().add(userRole);

        } else {

            requestedRoles.forEach(requestedRole -> {
                Role userRole = roleRepository.findByName(requestedRole.getName())
                        .orElseThrow(() -> new ServiceException("Role " + requestedRole.getName() + " was not found."));
                user.getRoles().add(userRole);
            });
        }

        user.setStatus(UserStatus.PENDING); // sets the status to pending
        userRepository.save(user);

        //Generate user registration confirmation code and persist it
        String verificationCode = idGenerator.generateAlphanumericId(10);
        ActionVerification actionVerification = new ActionVerification();
        actionVerification.setVerificationCode(verificationCode);
        actionVerification.setVerificationType(ActionVerificationType.USER_REGISTRATION);
        actionVerification.setUsername(user.getUsername());
        LocalDateTime now = LocalDateTime.now();
        actionVerification.setStartTimestamp(now);
        actionVerification.setEndTimestamp(now.plusDays(1)); //set to expire in 24 hours
        actionVerificationRepository.save(actionVerification);

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setReplyTo("no-reply@ebso.com");
        msg.setSubject("User Registration");
        msg.setText("Please activate your account.");

        // Passed to template-thymeleaf & mailMessgaes.properties to generate an email
        Map<String, Object> emailTemplateData = new HashMap<>();
        emailTemplateData.put("recipientName", user.getName().getFirstName());
        emailTemplateData.put("text", "Welcome to Ebso!  Please activate your account using reference code:  " + verificationCode + ".");
        emailTemplateData.put("senderName", "The Ebso Team");


        emailService.sendMessageUsingThymeleafTemplate(user.getEmail(), "Ebso Registration", emailTemplateData);
    }

    @Override
    public LocalDateTime updateLastLoginTimestamp(String username) {
        Optional<User> optionalUser = userRepository.findByUsername(username);
        if (optionalUser.isPresent()) {
            optionalUser.get().setLastLoginTimestamp(LocalDateTime.now());
            userRepository.save(optionalUser.get());

        } else {
            throw new ServiceException("User with username " + username + " does not exist!");
        }

        return optionalUser.get().getLastLoginTimestamp();
    }

    @Override
    public void updateRefreshToken(User user) {
        //I still need to implement this
    }

    @Override
    public void confirmRegistration(ActionVerification verification) {
        Optional<ActionVerification> optionalVerification = actionVerificationRepository.findByVerificationTypeAndUsernameAndEndTimestampGreaterThan(
                ActionVerificationType.USER_REGISTRATION, verification.getUsername(), LocalDateTime.now());

        LOGGER.debug("Current time:  {}", LocalDateTime.now());

        if (optionalVerification.isPresent()) {
            ActionVerification myVerification = optionalVerification.get();
            if (myVerification.getVerificationCode().equals(verification.getVerificationCode())) {
                //Set both the verification date and the expiration date of the verification date to now.
                //If we don't do that,the system will continue to update the record for the same verification code.
                //However, if the end date is less than the current time, it won't show in the search above.
                LocalDateTime now = LocalDateTime.now();
                myVerification.setVerificationTimestamp(now);
                myVerification.setEndTimestamp(now);

                Optional<User> optionalUser = userRepository.findByUsername(verification.getUsername());
                if (optionalUser.isPresent()) {
                    User user = optionalUser.get();
                    user.setStatus(UserStatus.ACTIVE);
                    userRepository.save(user);

                    actionVerificationRepository.save(myVerification);
                }
            } else {
                throw new InvalidVerificationCodeException("Verification code is incorrect!");
            }
        } else {
            String errorMessage = "Your registration code has expired and a new one has been sent to your email address.";
            // String errorCode = "E003";
            Optional<ActionVerification> optionalVCode =
                    actionVerificationRepository.findByVerificationTypeAndVerificationCodeAndUsername(
                            verification.getVerificationType(),
                            verification.getVerificationCode(),
                            verification.getUsername());
            if (optionalVCode.isPresent()) {

                throw new ServiceException(errorMessage);
            } else {
                //No verification code was ever sent to the user, which means that the user never registered.
                //Hmmm ... There could could also have been an email failure.
                errorMessage = "You have not registered with Ebso.  Please access the registration page to register.";
                throw new ServiceException(errorMessage);
            }
        }
    }

    @Override
    public void activateUser(User user) {
        Optional<User> optionalUser = userRepository.findByUsername(user.getUsername());
        if (optionalUser.isPresent()) {
            user.setStatus(UserStatus.ACTIVE);
            userRepository.save(optionalUser.get());

        } else {
            throw new ServiceException("User with username " + user.getUsername() + " does not exist!");
        }
    }

    @Override
    public void suspendUser(User user) {
        Optional<User> optionalUser = userRepository.findByUsername(user.getUsername());
        if (optionalUser.isPresent()) {
            user.setStatus(UserStatus.SUSPENDED);
            userRepository.save(optionalUser.get());

        } else {
            throw new ServiceException("User with username " + user.getUsername() + " does not exist!");
        }
    }

    @Override
    public void reinstateUser(User user) {
        Optional<User> optionalUser = userRepository.findByUsername(user.getUsername());
        if (optionalUser.isPresent()) {
            user.setStatus(UserStatus.ACTIVE);
            userRepository.save(optionalUser.get());

        } else {
            throw new ServiceException("User with username " + user.getUsername() + " does not exist!");
        }
    }

    @Override
    public void resetPassword(User user) {
        //TODO
    }

    public Page<User> getUsers(UserCriteria userCriteria,
                               Pageable pageRequest) {

        boolean criteriaPresent = false;

        if (userCriteria.getFirstName().isPresent()) {
            criteriaPresent = true;
        }

        if (userCriteria.getLastName().isPresent()) {
            criteriaPresent = true;
        }

        if (userCriteria.getCity().isPresent()) {
            criteriaPresent = true;
        }

        if (userCriteria.getState().isPresent()) {
            criteriaPresent = true;
        }

        if (userCriteria.getRoleName().isPresent()) {
            criteriaPresent = true;
        }

        if (!criteriaPresent)
            return userRepository.findAll(pageRequest);

        return userRepository.findAll(((root, criteriaQuery, criteriaBuilder) -> {
                    List<Predicate> predicates = new ArrayList<>();
                    if (userCriteria.getFirstName().isPresent())
                        predicates.add(criteriaBuilder.equal(EntitySpecification.getKey("name.firstName", root), userCriteria.getFirstName().get()));
                    if (userCriteria.getLastName().isPresent())
                        predicates.add(criteriaBuilder.equal(EntitySpecification.getKey("name.lastName", root), userCriteria.getLastName().get()));
                    if (userCriteria.getCity().isPresent())
                        predicates.add(criteriaBuilder.equal(EntitySpecification.getKey("address.city", root), userCriteria.getCity().get()));
                    if (userCriteria.getState().isPresent())
                        predicates.add(criteriaBuilder.equal(EntitySpecification.getKey("address.state", root), userCriteria.getState().get()));

                    if (userCriteria.getRoleName().isPresent()) {
                        Join<User, Role> roles = root.join("roles");
                        predicates.add(criteriaBuilder.equal(roles.get("name"), userCriteria.getRoleName().get()));
                    }

                    return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
                }),
                pageRequest);

    }
}



