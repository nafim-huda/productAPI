package com.mag7.ebso.ebsoapi.web.security.userdetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mag7.ebso.ebsoapi.entity.UserStatus;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Objects;

public class EbsoUserDetails implements UserDetails {
    private static final long serialVersionUID = 1L;

    private Long id;
    private String username;
    private String email;
    @JsonIgnore
    private String password;

    private String firstName;
    private String lastName;
    private String middleName;
    private UserStatus status;
    private String phoneNumber;

    private LocalDateTime lastLoginTimestamp;

    private Collection<? extends GrantedAuthority> authorities;

    public EbsoUserDetails(Long id,
                           String username,
                           String email,
                           String password,
                           String firstName,
                           String lastName,
                           String middleName,
                           UserStatus status,
                           String phoneNumber,
                           LocalDateTime lastLoginTimestamp,
                           Collection<? extends GrantedAuthority> authorities) {

        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.status = status;
        this.phoneNumber = phoneNumber;
        this.lastLoginTimestamp = lastLoginTimestamp;
        this.authorities = authorities;
    }

    public Long getId() {
        return id;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return UserStatus.ACTIVE.equals(status);
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public UserStatus getStatus() {
        return status;
    }

    public LocalDateTime getLastLoginTimestamp() {
        return lastLoginTimestamp;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EbsoUserDetails)) return false;
        EbsoUserDetails that = (EbsoUserDetails) o;
        return getUsername().equals(that.getUsername()) ||
                getEmail().equals(that.getEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUsername(), getEmail());
    }


    @Override
    public String toString() {
        return "EbsoUserDetails{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", status=" + status +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", lastLoginTimestamp=" + lastLoginTimestamp +
                ", authorities=" + authorities +
                '}';
    }
}
