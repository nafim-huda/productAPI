package com.mag7.ebso.ebsoapi.web.controller;

import com.mag7.ebso.ebsoapi.entity.RoleName;
import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.model.PageDTO;
import com.mag7.ebso.ebsoapi.model.UserDTO;
import com.mag7.ebso.ebsoapi.model.mapper.UserMapper;
import com.mag7.ebso.ebsoapi.service.UserService;
import com.mag7.ebso.ebsoapi.service.support.UserCriteria;
import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserMapper userMapper;

    @Autowired
    UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<?>  getUser(@PathVariable("id") Long id) {
        Optional<User> user = userService.getUser(id);

        if (!user.isPresent()) {
            EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
            ebsoResponse.getHeader().getMessages().add("User with id " + id + " was not found!");

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ebsoResponse);
        }

        EbsoResponse<UserDTO> ebsoResponse = new EbsoResponse<>();
        ebsoResponse.setBody(userMapper.toUserDTO(user.get()));

        return ResponseEntity.status(HttpStatus.OK).body(ebsoResponse);
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('HELPDESK') or hasRole('MANAGER')") // looks for authorities that has the ROLE prefix
    public ResponseEntity<?> getUsers(@RequestParam("firstName") Optional<String> firstName,
                                      @RequestParam("lastName") Optional<String> lastName,
                                      @RequestParam("city") Optional<String> city,
                                      @RequestParam("state") Optional<String> state,
                                      @RequestParam("roleName") Optional<RoleName> roleName,
                                      Pageable pageRequest) {


        Page<User> userPage = userService.getUsers(new UserCriteria(firstName,
                        lastName,
                        city,
                        state,
                        roleName),
                pageRequest);
        if (userPage.isEmpty()) {
            EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
            ebsoResponse.getHeader().getMessages().add("No results were found!");

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ebsoResponse);
        }

        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Total number of Elements {}, Page Size:  {}", userPage.getTotalElements(), userPage.getSize());

        EbsoResponse<PageDTO<UserDTO>> ebsoResponse = new EbsoResponse<>();
        ebsoResponse.setBody(userMapper.toPageDTO(userPage));

        return ResponseEntity.status(HttpStatus.OK).body(ebsoResponse);
    }
}