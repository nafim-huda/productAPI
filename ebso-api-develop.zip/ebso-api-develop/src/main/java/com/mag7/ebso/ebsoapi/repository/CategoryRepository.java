package com.mag7.ebso.ebsoapi.repository;

import com.mag7.ebso.ebsoapi.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    List<Category> findByParentNull();
    // Spring JPA is smart enough to know to find the categories that have null as their parent id,
    // top level categories

}
