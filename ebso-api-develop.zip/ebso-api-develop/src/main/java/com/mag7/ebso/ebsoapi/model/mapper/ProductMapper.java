package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.entity.Product;
import com.mag7.ebso.ebsoapi.model.PageDTO;
import com.mag7.ebso.ebsoapi.model.ProductDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface ProductMapper {
    ProductDTO toProductDTO(Product product);
    List<ProductDTO> toProductDTOs(List<Product> products);
    Product toProduct(ProductDTO productDTO);

    default PageDTO toPageDTO(Page<Product> productPage) {
        List<ProductDTO> productDTOs = productPage.stream()
                .map(this::toProductDTO)
                .collect(Collectors.toList());


        return PageDTOUtils.toPageDTO(productPage, productDTOs);
    }
}