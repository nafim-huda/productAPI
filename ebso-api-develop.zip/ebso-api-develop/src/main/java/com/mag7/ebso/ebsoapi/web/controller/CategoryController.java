package com.mag7.ebso.ebsoapi.web.controller;

import com.mag7.ebso.ebsoapi.entity.Category;
import com.mag7.ebso.ebsoapi.model.CategoryDTO;
import com.mag7.ebso.ebsoapi.model.mapper.CategoryMapper;
import com.mag7.ebso.ebsoapi.service.CategoryService;
import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/categories")
public class CategoryController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CategoryController.class);

    @Autowired
    CategoryMapper categoryMapper;

    @Autowired
    CategoryService categoryService;

    @GetMapping("/{id}")
    public ResponseEntity<?> getCategory(@PathVariable Long id) {
        Optional<Category> category = categoryService.getCategory(id);

        if (!category.isPresent()) {
            EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
            ebsoResponse.getHeader().getMessages().add("Category with id " + id + " was not found!");

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ebsoResponse);
        }

        EbsoResponse<CategoryDTO> ebsoResponse = new EbsoResponse<>();
        ebsoResponse.setBody(categoryMapper.toCategoryDTO(category.get()));

        return ResponseEntity.status(HttpStatus.OK).body(ebsoResponse);
    }

    @GetMapping("/")
    public ResponseEntity<?> getMainCategories() {
        List<Category> categories = categoryService.getMainCategories();

        if (categories != null && !categories.isEmpty()) {
            EbsoResponse<List<CategoryDTO>> ebsoResponse = new EbsoResponse<>();
            ebsoResponse.setBody(categoryMapper.toCategoryDTOs(categories));

            return ResponseEntity.status(HttpStatus.OK).body(ebsoResponse);
        }

        EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
        ebsoResponse.getHeader().getMessages().add("No results were found!");

        return ResponseEntity.status(HttpStatus.NOT_FOUND ).body(ebsoResponse);
    }


}
