package com.mag7.ebso.ebsoapi.entity;

public enum RoleName {
    ROLE_USER,
    ROLE_MERCHANT,
    ROLE_ADMIN,
    ROLE_HELPDESK,
    ROLE_MANAGER;
}
