package com.mag7.ebso.ebsoapi.service;

public class ServiceException extends RuntimeException {
    private String errorCode;

    public ServiceException() {
        super();
    }

    public ServiceException(String message) {
        super(message);
    }
    public ServiceException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public ServiceException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
