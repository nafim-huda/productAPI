package com.mag7.ebso.ebsoapi.model;

import java.io.Serializable;
import java.util.Objects;

public class NameDTO implements Serializable {
    private static final long serialVersionUID = -7400203494229361132L;

    private String firstName;
    private String lastName;
    private String middleName;

    public NameDTO() {
    }

    public NameDTO(String firstName, String lastName, String middleName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NameDTO)) return false;
        NameDTO nameDTO = (NameDTO) o;
        return getFirstName().equals(nameDTO.getFirstName()) &&
                getLastName().equals(nameDTO.getLastName()) &&
                Objects.equals(getMiddleName(), nameDTO.getMiddleName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getMiddleName());
    }

    @Override
    public String toString() {
        return "NameDTO{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleName='" + middleName + '\'' +
                '}';
    }
}
