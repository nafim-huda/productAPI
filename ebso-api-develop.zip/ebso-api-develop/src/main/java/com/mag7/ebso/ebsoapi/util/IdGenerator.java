package com.mag7.ebso.ebsoapi.util;

public interface IdGenerator {
    String generateAlphaId(int idlength);
    String generateAlphanumericId(int idLength);
}
