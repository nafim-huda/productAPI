package com.mag7.ebso.ebsoapi.web.controller;

import com.mag7.ebso.ebsoapi.entity.ActionVerification;
import com.mag7.ebso.ebsoapi.entity.Address;
import com.mag7.ebso.ebsoapi.entity.Name;
import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.model.*;
import com.mag7.ebso.ebsoapi.model.mapper.ActionVerificationMapper;
import com.mag7.ebso.ebsoapi.model.mapper.UserMapper;
import com.mag7.ebso.ebsoapi.service.exception.InvalidVerificationCodeException;
import com.mag7.ebso.ebsoapi.service.exception.ServiceException;
import com.mag7.ebso.ebsoapi.service.UserService;
import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import com.mag7.ebso.ebsoapi.web.security.token.TokenProvider;
import com.mag7.ebso.ebsoapi.web.security.userdetails.EbsoUserDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.Set;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController


@RequestMapping("/api/v1/auth")
public class AuthenticationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

    private static final String AUTHORIZATION_HEADER_VALUE_PREFIX = "Bearer ";

    // Injecting the name of the response token cookie
    @Value("${com.mag7.ebso.token.refresh.cookie.name}")
    private String cookieName;

    // Spring Framework class that authenticates users by working with UserDetails
    @Autowired
    AuthenticationManager authenticationManager;

    // Encoder
    @Autowired
    PasswordEncoder encoder;


    @Autowired
    UserService userService;

    @Autowired
    TokenProvider tokenProvider;

    @Autowired
    UserMapper userMapper;

    @Autowired
    ActionVerificationMapper actionVerificationMapper;

    @Value("${com.mag7.ebso.token.refresh.expiration}")
    private int refreshTokenExpiration;

    @Value("${com.mag7.ebso.token.jwt.expiration}")
    private int jwtTokenExpiration;

    @Value("${com.mag7.ebso.token.jwt.cookie.name}")
    private String jwtCookieName;

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody SignInDTO signInRequest, HttpServletResponse response) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Attempting to authenticate user");
        }
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(signInRequest.getUsername(), signInRequest.getPassword()));
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("User has been successfully authenticated!");
            LOGGER.debug("Now making the UserDetails object available in the current execution thread");
            LOGGER.debug("Also generating an ID token i.e. JWT token for the authenticated user to be included in the HTTP response");
        }
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = tokenProvider.createJwtToken(authentication);
        String refreshToken = tokenProvider.createRefreshToken(authentication);
        Cookie cookie = new Cookie(cookieName,refreshToken);

        //The setMaxAge method expect the value in seconds.  Since application.properties, the refresh token expiry is
        //expressed in minutes, we must multiply that by 60.  The cookie will expire at the exact same time as the token.
        cookie.setMaxAge(refreshTokenExpiration * 60);

        // This attributes instructs the browser to send the cookie back over a secure transport i.e. HTTPS
        // to protect the confidentiality of the data (it cannot be read)
        cookie.setSecure(true);

        // This prevents JavaScript from reading this value of the cookie
        cookie.setHttpOnly(true);

        // The browser will automatically send the cookie for any request from the API domain.
        // Locally, it is localhost (could easily have been ".somedomain.com")
        // If we want to restrict the cookie to a specific subpath (/products), the browser would send the
        // cookie when the request URL starts with that path after the domain name.
        cookie.setPath("/");

        // add cookie to response
        response.addCookie(cookie);

        ////////// Add JWT Cookie
        Cookie jwtCookie = new Cookie(jwtCookieName,jwt);

        jwtCookie.setMaxAge(jwtTokenExpiration * 60);

        jwtCookie.setSecure(true);

        jwtCookie.setHttpOnly(true);

        jwtCookie.setPath("/");

        // add cookie to response
        response.addCookie(jwtCookie);

        StringBuilder sb = new StringBuilder(AUTHORIZATION_HEADER_VALUE_PREFIX);
        sb.append(jwt);
        EbsoUserDetails userDetails = (EbsoUserDetails) authentication.getPrincipal();
        Set<String> roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toSet());
        EbsoResponse ebsoResponse = new EbsoResponse<AuthResponseDTO>();
        ebsoResponse.setBody( new AuthResponseDTO(userDetails.getUsername(),
                userDetails.getFirstName(),
                userDetails.getLastName(),
                userDetails.getMiddleName(),
                userDetails.getStatus().toString(),
                userDetails.getLastLoginTimestamp(),
                roles));
        ResponseEntity<EbsoResponse> responseEntity = ResponseEntity.ok(ebsoResponse);
        return responseEntity;
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserRegistrationDTO userRegistrationDTO) {
        User user = userMapper.toUser(userRegistrationDTO);
        user.setPassword(encoder.encode(user.getPassword()));

        LOGGER.debug("*****************User: {}", user.toString());

        EbsoResponse<String> ebsoResponse = new EbsoResponse<>();


        try {
            //When the user is saved, the status will be PENDING, then ACTIVE after email is verified
            userService.registerUser(user);

            ebsoResponse.getHeader().getMessages().add("Your registration request was submitted successfully.  Please verify your email.");
            return ResponseEntity.ok(ebsoResponse);
        } catch(ServiceException se) {
            // Log the exception and report a friendly message to the user
            ebsoResponse.getHeader().getErrors().add(new com.mag7.ebso.ebsoapi.web.controller.response.Error("E001", se.getMessage()));
            return ResponseEntity.badRequest().body(ebsoResponse);
        } catch (MessagingException me) {
            ebsoResponse.getHeader().getErrors().add(new com.mag7.ebso.ebsoapi.web.controller.response.Error("E001", me.getMessage()));
            return ResponseEntity.badRequest().body(ebsoResponse);
        } catch (IOException ioe) {
            ebsoResponse.getHeader().getErrors().add(new com.mag7.ebso.ebsoapi.web.controller.response.Error("E001", ioe.getMessage()));
            return ResponseEntity.badRequest().body(ebsoResponse);
        }
    }

    @PostMapping("/confirmregistration")
    public ResponseEntity<?> registerUser(@Valid @RequestBody ActionVerificationDTO actionVerificationDTO) {
        ActionVerification actionVerification  = actionVerificationMapper.toActionVerification(actionVerificationDTO);

        EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
        try {
            //I will validate username and password before proceeding with the verification later

            // confirms the registration
            userService.confirmRegistration(actionVerification);

            ebsoResponse.getHeader().getMessages().add("Congratulations!  Your account is now activated!");
            return ResponseEntity.ok(ebsoResponse);
        } catch(InvalidVerificationCodeException ivce) {
            ebsoResponse.getHeader().getErrors().add(new com.mag7.ebso.ebsoapi.web.controller.response.Error("R001", ivce.getMessage()));
            return ResponseEntity.badRequest().body(ebsoResponse);
        } catch (ServiceException se) {
            //If we are here, the code probably has expired.
            //The system should probably send a new email verification code, I'll work on that later
            ebsoResponse.getHeader().getErrors().add(new com.mag7.ebso.ebsoapi.web.controller.response.Error("E002", se.getMessage()));
            return ResponseEntity.badRequest().body(ebsoResponse);
        }

    }
}

