package com.mag7.ebso.ebsoapi.model;

import com.mag7.ebso.ebsoapi.entity.ActionVerificationType;

import java.io.Serializable;
import java.time.LocalDateTime;

public class ActionVerificationDTO implements Serializable {
    private static final long serialVersionUID = 4830214166141893689L;

    private Long id;
    private Long version;
    private String verificationCode;
    private ActionVerificationType verificationType;
    private String username;
    private LocalDateTime verificationTimestamp;
    private LocalDateTime startTimestamp;
    private LocalDateTime endTimestamp;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public ActionVerificationType getVerificationType() {
        return verificationType;
    }

    public void setVerificationType(ActionVerificationType verificationType) {
        this.verificationType = verificationType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LocalDateTime getVerificationTimestamp() {
        return verificationTimestamp;
    }

    public void setVerificationTimestamp(LocalDateTime verificationTimestamp) {
        this.verificationTimestamp = verificationTimestamp;
    }

    public LocalDateTime getStartTimestamp() {
        return startTimestamp;
    }

    public void setStartTimestamp(LocalDateTime startTimestamp) {
        this.startTimestamp = startTimestamp;
    }

    public LocalDateTime getEndTimestamp() {
        return endTimestamp;
    }

    public void setEndTimestamp(LocalDateTime endTimestamp) {
        this.endTimestamp = endTimestamp;
    }
}
