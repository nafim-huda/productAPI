package com.mag7.ebso.ebsoapi.web.security.token;

import com.mag7.ebso.ebsoapi.web.security.token.jwt.JwtDetails;
import org.springframework.security.core.Authentication;

import java.util.Optional;

public interface TokenProvider {
    String createJwtToken(Authentication authentication);
    String createRefreshToken(Authentication authentication);

    JwtDetails refreshTokenIfNecessary(String refreshToken, String jwtToken);

    Optional<String> extractFromBearerToken(String bearerToken);
    String getUsername(String securityToken);
}

