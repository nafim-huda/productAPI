package com.mag7.ebso.ebsoapi.web.controller;

import com.mag7.ebso.ebsoapi.entity.Product;
import com.mag7.ebso.ebsoapi.model.PageDTO;
import com.mag7.ebso.ebsoapi.model.ProductDTO;
import com.mag7.ebso.ebsoapi.model.mapper.ProductMapper;
import com.mag7.ebso.ebsoapi.service.ProductService;
import com.mag7.ebso.ebsoapi.service.support.ProductCriteria;
import com.mag7.ebso.ebsoapi.util.EbsoUtils;
import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    ProductService productService;

    @Autowired
    ProductMapper productMapper;

    @GetMapping("/{id}")
    public ResponseEntity<?> getProduct(@PathVariable Long id) {

        Optional<Product> product = productService.getProduct(id);

        if (!product.isPresent()) {
            EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
            ebsoResponse.getHeader().getMessages().add("The product with id " + id + " was not found!");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ebsoResponse);
        }

        EbsoResponse<ProductDTO> ebsoResponse = new EbsoResponse<>();
        ebsoResponse.setBody(productMapper.toProductDTO(product.get()));

        return ResponseEntity.status(HttpStatus.OK).body(ebsoResponse);
    }

    @GetMapping
    public ResponseEntity<?> getProducts(@RequestParam("categoryId") Optional<Long> categoryId,
                                         @RequestParam("displayName") Optional<String> product_display_name,
                                         @RequestParam("minimumPrice") Optional<BigDecimal> minimumPrice,
                                         @RequestParam("maximumPrice") Optional<BigDecimal> maximumPrice,
                                         @RequestParam("merchantId") Optional<Long> merchantId,
                                         Pageable pageRequest) {

        Page<Product> productPage = productService.getProducts(new ProductCriteria(categoryId,
                        product_display_name,
                        minimumPrice,
                        maximumPrice,
                        merchantId),
                pageRequest);

        if (productPage.isEmpty()) {
            EbsoResponse<String> ebsoResponse = new EbsoResponse<>();
            ebsoResponse.getHeader().getMessages().add("No results were found!");

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ebsoResponse);
        }


        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Total number of Elements {}, Page Size:  {}", productPage.getTotalElements(), productPage.getSize());

        EbsoResponse<PageDTO<ProductDTO>> ebsoResponse = new EbsoResponse<>();
        ebsoResponse.setBody(productMapper.toPageDTO(productPage));

        return ResponseEntity.status(HttpStatus.OK).body(ebsoResponse);
    }

}
