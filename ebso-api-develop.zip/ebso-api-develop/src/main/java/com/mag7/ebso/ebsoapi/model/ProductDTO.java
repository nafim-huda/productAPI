package com.mag7.ebso.ebsoapi.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

public class ProductDTO implements Serializable {

    private static final long serialVersionUID = 6016586508581203820L;

    private Long id;
    private Long version;
    private String product_name;
    private String product_display_name;
    private String product_photoUrl;
    private BigDecimal price;
    private Integer stockQuantity;
    private Integer likes;
    private Integer views;
    private CategoryDTO category;
    private UserDTO merchant;
    private LocalDateTime createTimestamp;
    private LocalDateTime updateTimestamp;

    public ProductDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_display_name() {
        return product_display_name;
    }

    public void setProduct_display_name(String product_display_name) {
        this.product_display_name = product_display_name;
    }

    public String getProduct_photoUrl() {
        return product_photoUrl;
    }

    public void setProduct_photoUrl(String product_photoUrl) {
        this.product_photoUrl = product_photoUrl;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Integer getViews() {
        return views;
    }

    public void setViews(Integer views) {
        this.views = views;
    }

    public CategoryDTO getCategory() {
        return category;
    }

    public void setCategory(CategoryDTO category) {
        this.category = category;
    }

    public UserDTO getMerchant() {
        return merchant;
    }

    public void setMerchant(UserDTO merchant) {
        this.merchant = merchant;
    }

    public LocalDateTime getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(LocalDateTime createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public LocalDateTime getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(LocalDateTime updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ProductDTO)) return false;
        ProductDTO that = (ProductDTO) o;
        return Objects.equals(getId(), that.getId()) &&
                getProduct_name().equals(that.getProduct_name()) &&
                getProduct_display_name().equals(that.getProduct_display_name()) &&
                getProduct_photoUrl().equals(that.getProduct_photoUrl()) &&
                getPrice().equals(that.getPrice()) &&
                getStockQuantity().equals(that.getStockQuantity()) &&
                getLikes().equals(that.getLikes()) &&
                getViews().equals(that.getViews()) &&
                getCategory().equals(that.getCategory()) &&
                getMerchant().equals(that.getMerchant()) &&
                getCreateTimestamp().equals(that.getCreateTimestamp()) &&
                Objects.equals(getUpdateTimestamp(), that.getUpdateTimestamp());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getProduct_name(), getProduct_display_name(), getProduct_photoUrl(), getPrice(), getStockQuantity(), getLikes(), getViews(), getCategory(), getMerchant(), getCreateTimestamp());
    }

    @Override
    public String toString() {
        return "ProductDTO{" +
                "id=" + id +
                ", version=" + version +
                ", name='" + product_name + '\'' +
                ", displayName='" + product_display_name + '\'' +
                ", photoUrl='" + product_photoUrl + '\'' +
                ", price=" + price +
                ", stockQuantity=" + stockQuantity +
                ", likes=" + likes +
                ", views=" + views +
                ", category=" + category +
                ", merchant=" + merchant +
                ", createTimestamp=" + createTimestamp +
                ", updateTimestamp=" + updateTimestamp +
                '}';
    }
}
