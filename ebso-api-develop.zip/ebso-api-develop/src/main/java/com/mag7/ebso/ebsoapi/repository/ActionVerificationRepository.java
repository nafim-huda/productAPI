package com.mag7.ebso.ebsoapi.repository;

import com.mag7.ebso.ebsoapi.entity.ActionVerification;
import com.mag7.ebso.ebsoapi.entity.ActionVerificationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface ActionVerificationRepository extends JpaRepository<ActionVerification, Long> {
    Optional<ActionVerification> findByVerificationTypeAndUsernameAndEndTimestampGreaterThan(
            ActionVerificationType verificationType,
            String username,
            LocalDateTime date);

    Optional<ActionVerification> findByVerificationTypeAndVerificationCodeAndUsername(
            ActionVerificationType verificationType,
            String verificationCode,
            String username);
}
