package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.model.PageDTO;
import com.mag7.ebso.ebsoapi.model.SortPropertyDTO;
import org.springframework.data.domain.Page;

import java.util.List;

import static java.util.stream.Collectors.toList;

public class PageDTOUtils {
    public static <T, S> PageDTO<T> toPageDTO(Page<S> page, List<T> itemDTOs) {


        List<SortPropertyDTO> sortPropertyDTOs = page.getSort().stream()
                .map(order -> {
                    final SortPropertyDTO.Direction direction = SortPropertyDTO.Direction.valueOf(order.getDirection().name());
                    final String property = order.getProperty();

                    return new SortPropertyDTO(property, direction); })

                .collect(toList());




        PageDTO<T> pageDTO = new PageDTO<T>(itemDTOs,
                page.getTotalElements(),
                page.getSize(),
                page.getNumber(),
                sortPropertyDTOs);

        return pageDTO;
    }
}
