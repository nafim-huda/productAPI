package com.mag7.ebso.ebsoapi.service.support;

import com.mag7.ebso.ebsoapi.entity.RoleName;

import java.io.Serializable;
import java.util.Optional;

public class UserCriteria implements Serializable {
    private static final long serialVersionUID = 8416415998935123787L;

    private Optional<String> firstName;
    private Optional<String> lastName;
    private Optional<String> city;
    private Optional<String> state;
    private Optional<RoleName> roleName;

    public UserCriteria() {
    }

    public UserCriteria(Optional<String> firstName,
                        Optional<String> lastName,
                        Optional<String> city,
                        Optional<String> state,
                        Optional<RoleName> roleName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.city = city;
        this.state = state;
        this.roleName = roleName;
    }

    public Optional<String> getFirstName() {
        return firstName;
    }

    public void setFirstName(Optional<String> firstName) {
        this.firstName = firstName;
    }

    public Optional<String> getLastName() {
        return lastName;
    }

    public void setLastName(Optional<String> lastName) {
        this.lastName = lastName;
    }

    public Optional<String> getCity() {
        return city;
    }

    public void setCity(Optional<String> city) {
        this.city = city;
    }

    public Optional<String> getState() {
        return state;
    }

    public void setState(Optional<String> state) {
        this.state = state;
    }

    public Optional<RoleName> getRoleName() {
        return roleName;
    }

    public void setRoleName(Optional<RoleName> roleName) {
        this.roleName = roleName;
    }

    @Override
    public String toString() {
        return "UserCriteria{" +
                "firstName=" + firstName +
                ", lastName=" + lastName +
                ", city=" + city +
                ", state=" + state +
                ", roleName=" + roleName +
                '}';
    }
}
