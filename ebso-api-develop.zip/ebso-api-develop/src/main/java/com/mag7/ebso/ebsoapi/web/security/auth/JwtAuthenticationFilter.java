package com.mag7.ebso.ebsoapi.web.security.auth;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mag7.ebso.ebsoapi.web.security.token.TokenProvider;
import com.mag7.ebso.ebsoapi.web.security.token.jwt.JwtDetails;
import com.mag7.ebso.ebsoapi.web.security.userdetails.EbsoUserDetailsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.WebUtils;

//
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    // Filter, determines weather  an action is allowed
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Autowired
    private TokenProvider tokenProvider;

    @Autowired
    private EbsoUserDetailsService userDetailsService;

    @Value("${com.mag7.ebso.token.refresh.cookie.name}")
    private String cookieName;

    @Value("${com.mag7.ebso.token.jwt.cookie.name}")
    private String jwtTokenCookieName;

    @Value("${com.mag7.ebso.token.jwt.expiration}")
    private int jwtTokenExpiration;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String jwtToken = parseJwtToken(request); // JWT Token
        String refreshToken = parseRefreshToken(request); // Refresh Token

        if (StringUtils.hasText(refreshToken) && StringUtils.hasText(jwtToken)) {
            // If the JWT Token & refresh token are not empty or null, do the following:
            try {
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Read ID token from the HTTP request, validate it, extract the username from it and look up the user in the DB");
                }

                // Generates a new JWT token if it has expired
                JwtDetails jwtDetails = tokenProvider.refreshTokenIfNecessary(refreshToken, jwtToken);


                //Set the JWT token in a cookie in a response header
                if (StringUtils.hasText(jwtDetails.getToken().get())) {
                    Cookie cookie = new Cookie(jwtTokenCookieName,jwtDetails.getToken().get());

                    //Multiply by 60 b/c setMaxAge method is in seconds.
                    // the refresh token expiry is expressed in minutes (in application.properties)
                    // The cookie will expire at the exact same time as the token.
                    cookie.setMaxAge(jwtTokenExpiration * 60);

                    // This attributes instructs the browser to send the cookie back over a secure transport (HTTPS)
                    // to protect the confidentiality of the data (it cannot be read).
                    cookie.setSecure(true);

                    // This prevents JavaScript from reading this value of the cookie
                    cookie.setHttpOnly(true);

                    // The browser will automatically send the cookie for any request from the API domain.
                    // Locally, it is localhost.  However, this could easily have been ".somedomain.com".
                    // If we want to restrict the cookie to a specific subpath (/products), the browser would send the
                    // cookie when the request URL starts with that path after the domain name.
                    cookie.setPath("/");

                    // add cookie to response
                    response.addCookie(cookie);
                }

                if (jwtDetails.getUsername().isPresent()) {
                    String username = jwtDetails.getUsername().get();

                    // retrieves user details(email, role, disabled, etc) based on a given username
                    UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                    // Wrapper around user details that allows us to put them in thread local
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());


                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug("JWT token is valid and so, make UserDetails object available in the current execution thread");
                    }
                    // Puts user details in thread local so they can be accessed by all of the other filters in the filter chain
                    SecurityContextHolder.getContext().setAuthentication(authentication);

                }
            } catch (Exception e) {
                LOGGER.error("Unable to set user authentication: {}", e);
            }
        }

        filterChain.doFilter(request, response);
    }

    private String parseRefreshToken(HttpServletRequest request) {
        // Gets refresh token
        Cookie refreshTokenCookie = WebUtils.getCookie(request, cookieName);

        if (refreshTokenCookie != null) {
            return refreshTokenCookie.getValue();
            // returns value of refresh token
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Refresh token cookie was not in the request!");
        }
        return null;
    }

    private String parseJwtToken(HttpServletRequest request) {
        Cookie jwtTokenCookie = WebUtils.getCookie(request, jwtTokenCookieName);
        if (jwtTokenCookie != null)
            return jwtTokenCookie.getValue();
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("JWT token cookie was not in the request!");
        return null;
    }


}
