package com.mag7.ebso.ebsoapi.web.security.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class EbsoAccessDeniedHandler implements AccessDeniedHandler {

    // Whenever we get an access denied handler, we do the following
    @Override
    public void handle(HttpServletRequest request,
                       HttpServletResponse response,
                       AccessDeniedException exception) throws IOException, ServletException {

        ObjectMapper objectMapper = new ObjectMapper();
        EbsoResponse ebsoResponse = new EbsoResponse();
        ebsoResponse.getHeader().getErrors().add(new com.mag7.ebso.ebsoapi.web.controller.response.Error("403",
                exception.getMessage()));
        response.setStatus(HttpStatus.FORBIDDEN.value());
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        objectMapper.writeValue(response.getOutputStream(), ebsoResponse);

    }
}
