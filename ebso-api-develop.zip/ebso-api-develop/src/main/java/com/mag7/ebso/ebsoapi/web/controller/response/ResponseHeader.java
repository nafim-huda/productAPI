package com.mag7.ebso.ebsoapi.web.controller.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ResponseHeader implements Serializable {
    private static final long serialVersionUID = 7322088703826586855L;

    //private String token;
    private List<Error> errors = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();
    private List<String> messages = new ArrayList<>();

    public ResponseHeader() {
    }

//    public String getToken() {
//        return token;
//    }

//    public void setToken(String token) {
//        this.token = token;
//    }

    public List<Error> getErrors() {
        return errors;
    }

    public List<String> getWarnings() {
        return warnings;
    }

    public List<String> getMessages() {
        return messages;
    }

    @Override
    public String toString() {
        return "ResponseHeader{" +
              //  "token='" + token + '\'' +
                ", errors=" + errors +
                ", warnings=" + warnings +
                ", messages=" + messages +
                '}';
    }
}
