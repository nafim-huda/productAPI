package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.entity.Cart;
import com.mag7.ebso.ebsoapi.entity.CartItem;
import com.mag7.ebso.ebsoapi.entity.Product;
import com.mag7.ebso.ebsoapi.model.CartDTO;
import com.mag7.ebso.ebsoapi.model.CartItemDTO;
import com.mag7.ebso.ebsoapi.model.PageDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface CartMapper {
    CartDTO toCartDTO(Cart cart);
    Cart toCart(CartDTO cartDTO);

    CartItemDTO toCartItemDTO(CartItem cartItem);
    List<CartItemDTO> toCartItemDTOs(List<CartItem> items);
    CartItem toCartItem(CartItemDTO cartItemDTO);

    default PageDTO toPageDTO(Page<CartItem> cartItemPage) {
        List<CartItemDTO> cartItemDTOs = cartItemPage.stream()
                .map(this::toCartItemDTO)
                .collect(Collectors.toList());


        return PageDTOUtils.toPageDTO(cartItemPage, cartItemDTOs);
    }
}
