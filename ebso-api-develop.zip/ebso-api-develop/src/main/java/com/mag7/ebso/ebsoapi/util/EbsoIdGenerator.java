package com.mag7.ebso.ebsoapi.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.SecureRandom;
import java.time.ZoneId;
import java.util.Random;

// Using this class to generate order numbers and email verification code
public class EbsoIdGenerator  implements IdGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsoIdGenerator.class);

    //ASCII range for 0 - 9 :  [48 - 57]
    private static final int LEFT_NUMERIC_LIMIT = 48;
    private static final int RIGHT_NUMERIC_LIMIT = 57;

    //ASCII range for A - Z :  [65 - 90]
    private static final int LEFT_ALPHA_LIMIT = 65;
    private static final int RIGHT_ALPHA_LIMIT = 90;

    @Override
    public String generateAlphaId(int idLength) {
        // generates id with alphabetical characters
        Random random = new SecureRandom();

        String generatedId = random.ints(LEFT_ALPHA_LIMIT, RIGHT_ALPHA_LIMIT + 1)
                .limit(idLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Generated alpha ID:  {}", generatedId);

        return generatedId;
    }

    /**
     *
     *
     * @param idLength length you want the id to be
     * @return
     */

    @Override
    public String generateAlphanumericId(int idLength) {
        // generates id with characters and numbers
        Random random = new SecureRandom();

        String generatedId = random.ints(LEFT_NUMERIC_LIMIT, RIGHT_ALPHA_LIMIT + 1) //  random numbers between 0 and 9
                .filter(i -> (i <= RIGHT_NUMERIC_LIMIT || i >= LEFT_ALPHA_LIMIT) && (i <= RIGHT_ALPHA_LIMIT))
                .limit(idLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Generated alphanumeric ID:  {}", generatedId);

        return generatedId;
    }

    public static void main(String[] args) {
        IdGenerator idGenerator = new EbsoIdGenerator();

        idGenerator.generateAlphaId(10);
        idGenerator.generateAlphanumericId(10);
    }
}
