package com.mag7.ebso.ebsoapi.web.security.token;

import org.springframework.security.core.Authentication;

public interface IdTokenService {

    public String generateIdToken(Authentication authenticationToken);
    public String getUsername(String securityToken);
    public boolean validateIdToken(String authenticationToken);
}
