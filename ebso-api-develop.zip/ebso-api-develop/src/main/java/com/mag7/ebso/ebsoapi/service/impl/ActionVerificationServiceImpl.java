package com.mag7.ebso.ebsoapi.service.impl;

import com.mag7.ebso.ebsoapi.entity.ActionVerification;
import com.mag7.ebso.ebsoapi.service.ActionVerificationService;

public class ActionVerificationServiceImpl implements ActionVerificationService {
    @Override
    public ActionVerification getRegistrationVerification(String username) {
        // I still need to implement this (may not need this because we are
        // working with the repository directly)
        return null;
    }

    @Override
    public void confirmUserRegistration(ActionVerification actionVerification) {
        // I still need to implement this
    }
}
