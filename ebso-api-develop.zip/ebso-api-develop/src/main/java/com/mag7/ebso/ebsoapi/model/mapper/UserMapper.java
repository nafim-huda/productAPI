package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.entity.Name;
import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.model.NameDTO;
import com.mag7.ebso.ebsoapi.model.PageDTO;
import com.mag7.ebso.ebsoapi.model.UserDTO;
import com.mag7.ebso.ebsoapi.model.UserRegistrationDTO;
import org.mapstruct.Mapper;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserDTO toUserDTO(User user);

    List<UserDTO> toUserDTOs(List<User> users);
    User toUser(UserDTO userDTO);

    NameDTO toNameDTO(Name name);
    Name toName(NameDTO name);

    User toUser(UserRegistrationDTO userRegistrationDTO);

    default PageDTO toPageDTO(Page<User> userPage) {
        List<UserDTO> userDTOs = userPage.stream()
                .map(this::toUserDTO)
                .collect(Collectors.toList());

        return PageDTOUtils.toPageDTO(userPage, userDTOs);
    }
}
