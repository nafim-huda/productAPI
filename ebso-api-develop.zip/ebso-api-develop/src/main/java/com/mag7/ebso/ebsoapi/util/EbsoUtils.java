package com.mag7.ebso.ebsoapi.util;

import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.web.security.token.AppContextHolder;
import com.mag7.ebso.ebsoapi.web.security.userdetails.EbsoUserDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;

public class EbsoUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsoUtils.class);
    public  static String getJwtToken() {
        return AppContextHolder.getContext().getToken();
    }

    public static EbsoUserDetails getUserDetails() {
        // Retrieves user details
        EbsoUserDetails  userDetails = null;

        if (SecurityContextHolder.getContext().getAuthentication() != null) {
            Object userDetailsObject = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (userDetailsObject != null) {
                if (userDetailsObject instanceof EbsoUserDetails)
                    userDetails = (EbsoUserDetails) userDetailsObject;
                else {
                    if (LOGGER.isDebugEnabled())
                        LOGGER.debug("userDetailsObject is not of type EbsoUserDetails.  Actual type is {}.", userDetailsObject.getClass());
                }
            } else {
                if (LOGGER.isDebugEnabled())
                    LOGGER.debug("userDetailsObject is null!");
            }
        } else {
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("Authentication object is null!");
        }

        return userDetails;
    }

    public static User getSimpleUserEntity() {
        User user = new User();
        user.setId(getUserDetails().getId());

        return user;
    }
}
