package com.mag7.ebso.ebsoapi.web.controller.advice;

import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import com.mag7.ebso.ebsoapi.web.controller.response.Error;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

// Demonstrates exception handling
@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ExceptionHandlingAdvice {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandlingAdvice.class);


    @ExceptionHandler(value = { BadCredentialsException.class })
    public ResponseEntity<Object> handleUnauthorizedException(BadCredentialsException ex) {

        LOGGER.error("Unauthorized Exception: ",ex.getMessage());

        EbsoResponse ebsoResponse = new EbsoResponse();
        ebsoResponse.getHeader().getErrors().add(new Error(HttpStatus.UNAUTHORIZED.toString(), ex.getMessage()));
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ebsoResponse);
    }

    @ExceptionHandler(value = {AuthenticationException.class })
    public ResponseEntity<Object> handleException(AuthenticationException ex) {

        LOGGER.error("Exception: ",ex.getMessage());
        EbsoResponse ebsoResponse = new EbsoResponse();
        ebsoResponse.getHeader().getErrors().add(new Error(HttpStatus.UNAUTHORIZED.toString(), ex.getMessage()));

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ebsoResponse);
    }

    @ExceptionHandler(value = { AccessDeniedException.class })
    public ResponseEntity<Object> handleException(AccessDeniedException ex) {

        LOGGER.error("Exception: ",ex.getMessage());
        EbsoResponse ebsoResponse = new EbsoResponse();
        ebsoResponse.getHeader().getErrors().add(new Error(HttpStatus.FORBIDDEN.toString(), ex.getMessage()));

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ebsoResponse);
    }

    //@ExceptionHandler(value = { Exception.class })
    public ResponseEntity<Object> handleException(Exception ex) {

        LOGGER.error("Exception: ",ex.getMessage());
        EbsoResponse ebsoResponse = new EbsoResponse();
        ebsoResponse.getHeader().getErrors().add(new Error(HttpStatus.INTERNAL_SERVER_ERROR.toString(), ex.getMessage()));

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ebsoResponse);
    }

}
