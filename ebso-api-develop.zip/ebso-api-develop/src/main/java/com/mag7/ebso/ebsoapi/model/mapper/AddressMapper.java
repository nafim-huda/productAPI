package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.entity.Address;
import com.mag7.ebso.ebsoapi.model.AddressDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AddressMapper {
    AddressDTO toNameDTO(Address name);
    Address toName(AddressDTO nameDTO);
}
