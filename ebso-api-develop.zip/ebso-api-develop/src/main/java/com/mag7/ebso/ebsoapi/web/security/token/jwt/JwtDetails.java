package com.mag7.ebso.ebsoapi.web.security.token.jwt;

import java.io.Serializable;
import java.util.Optional;

public class JwtDetails implements Serializable {
    private Optional<String> username;
    private Optional<String> token;

    public JwtDetails(Optional<String> username, Optional<String> token) {
        this.username = username;
        this.token = token;
    }

    public Optional<String> getUsername() {
        return username;
    }

    public Optional<String> getToken() {
        return token;
    }
}
