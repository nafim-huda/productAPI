package com.mag7.ebso.ebsoapi.service;

import com.mag7.ebso.ebsoapi.entity.RefreshToken;

import java.time.LocalDateTime;
import java.util.Optional;

public interface RefreshTokenService {
    public Optional<RefreshToken> getUserRefreshToken(String username);
    public Optional<RefreshToken> getRefreshTokenDetails(String token);
    public void saveToken(RefreshToken token);
    public void invalidateToken(String token);

}
