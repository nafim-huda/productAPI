package com.mag7.ebso.ebsoapi.entity;

public enum ActionVerificationType {
    USER_REGISTRATION,
    PASSWORD_RESET
}
