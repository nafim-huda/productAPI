package com.mag7.ebso.ebsoapi.repository.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EntitySpecification<T> implements Specification<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EntitySpecification.class);

    private List<QueryCondition> conditions = new ArrayList<>();

    public void add(QueryCondition condition) {
        conditions.add(condition);
    }

    @Override
    public Specification<T> and(Specification<T> other) {
        return this.and(other);
    }

    @Override
    public Specification<T> or(Specification<T> other) {
        return this.or(other);
    }

    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {

        LOGGER.debug(">>>>> toPredicate");

        List<Predicate> predicates = new ArrayList<>();

        //add add criteria to predicates

        for (QueryCondition condition : conditions) {
            if (condition.getOperator().equals(QueryOperator.GREATER_THAN)) {
                predicates.add(criteriaBuilder.greaterThan(root.get(condition.getKey()), condition.getValues()[0].toString()));
            } else if (condition.getOperator().equals(QueryOperator.LESS_THAN)) {
                predicates.add(criteriaBuilder.lessThan(
                        root.get(condition.getKey()), condition.getValues()[0].toString()));
            } else if (condition.getOperator().equals(QueryOperator.GREATER_THAN_EQUAL)) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(
                        root.get(condition.getKey()), condition.getValues()[0].toString()));
            } else if (condition.getOperator().equals(QueryOperator.LESS_THAN_EQUAL)) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(
                        root.get(condition.getKey()), condition.getValues()[0].toString()));
            } else if (condition.getOperator().equals(QueryOperator.NOT_EQUAL)) {
                predicates.add(criteriaBuilder.notEqual(
                        root.get(condition.getKey()), condition.getValues()[0]));
            } else if (condition.getOperator().equals(QueryOperator.EQUAL)) {
                predicates.add(criteriaBuilder.equal(
                        root.get(condition.getKey()), condition.getValues()[0]));
            } else if (condition.getOperator().equals(QueryOperator.MATCH)) {
                predicates.add(criteriaBuilder.like(
                        criteriaBuilder.lower(getKey(condition.getKey(), root)),
                        "%" + condition.getValues()[0].toString().toLowerCase() + "%"));
            } else if (condition.getOperator().equals(QueryOperator.MATCH_END)) {
                predicates.add(criteriaBuilder.like(
                        criteriaBuilder.lower(root.get(condition.getKey())),
                        condition.getValues()[0].toString().toLowerCase() + "%"));
            } else if (condition.getOperator().equals(QueryOperator.MATCH_START)) {
                predicates.add(criteriaBuilder.like(
                        criteriaBuilder.lower(root.get(condition.getKey())),
                        "%" + condition.getValues()[0].toString().toLowerCase()));
            } else if (condition.getOperator().equals(QueryOperator.IN)) {
                predicates.add(criteriaBuilder.in(root.get(condition.getKey())).value(condition.getValues()[0]));
            } else if (condition.getOperator().equals(QueryOperator.NOT_IN)) {
                predicates.add(criteriaBuilder.not(root.get(condition.getKey())).in(condition.getValues()[0]));
            } else if (QueryOperator.IS_NULL.equals(condition.getOperator())) {
                predicates.add(criteriaBuilder.isNull(root.get(condition.getKey())));
            } else if (QueryOperator.IS_NOT_NULL.equals(condition.getOperator())) {
                predicates.add(criteriaBuilder.isNotNull(root.get(condition.getKey())));
            } else if (QueryOperator.BETWEEN.equals(condition.getOperator())) {
                if (condition.getValues()[0] instanceof LocalDate) {
                    predicates.add(criteriaBuilder.between(root.get(condition.getKey()), (LocalDate)condition.getValues()[0], (LocalDate)condition.getValues()[1]));
                } else if (condition.getValues()[0] instanceof Integer) {
                    predicates.add(criteriaBuilder.between(root.get(condition.getKey()), (Integer)condition.getValues()[0], (Integer)condition.getValues()[1]));
                } else if (condition.getValues()[0] instanceof Double) {
                    predicates.add(criteriaBuilder.between(root.get(condition.getKey()), (Double)condition.getValues()[0], (Double)condition.getValues()[1]));
                } else {
                    throw new IllegalArgumentException("Unsupported data type for " + condition.getKey());
                }
            }
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    public static <Y,T> Path<Y> getKey(String key, Root<T> root) {
        String[] nestedProperties = key.split("\\.");

        Path<Y> path = root.get(nestedProperties[0]);

        if (nestedProperties.length > 1) {
            for (int i = 1; i < nestedProperties.length; i++ ) {
                path = path.get(nestedProperties[i]);
            }
        }

        return path;
    }

    public boolean isEmpty() {
        return conditions.isEmpty();
    }

}


