package com.mag7.ebso.ebsoapi.web.controller.response;

import java.io.Serializable;

// Every Controller returns an EbsoResponse, standardizes response that we set
public class EbsoResponse<T> implements Serializable {
    private static final long serialVersionUID = 2617741535460123893L;

    // Every response will have a header
    private ResponseHeader header = new ResponseHeader();

    // Generic type that can be anything depending on the controller(User, product, categories, etc)
    private T body;

    public ResponseHeader getHeader() {
        return header;
    }

    public void setHeader(ResponseHeader header) {
        this.header = header;
    }

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "EbsoResponse{" +
                "header=" + header +
                ", body=" + body +
                '}';
    }
}
