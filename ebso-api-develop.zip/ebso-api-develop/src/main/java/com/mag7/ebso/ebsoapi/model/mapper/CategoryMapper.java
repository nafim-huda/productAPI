package com.mag7.ebso.ebsoapi.model.mapper;

import com.mag7.ebso.ebsoapi.entity.Category;
import com.mag7.ebso.ebsoapi.model.CategoryDTO;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CategoryMapper {
    CategoryDTO toCategoryDTO(Category category);
    List<CategoryDTO> toCategoryDTOs(List<Category> categories);
    Category toCategory(CategoryDTO categoryDTO);
}
