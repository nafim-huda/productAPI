package com.mag7.ebso.ebsoapi.entity;


import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "products",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"name", "category_id"})
        })
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private Long version;

    @NotBlank
    @Size(max = 50)
    private String product_name;

    @NotBlank
    @Size(max = 100)
    private String product_display_name;

    @NotBlank
    @Size(max = 250)
    private String product_photoUrl;

    @NotNull
    private BigDecimal price;

    @NotNull
    private Integer stockQuantity;

    @NotNull
    private Integer likes;

    @NotNull
    private Integer views;

    @NotBlank
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", referencedColumnName = "id")
    private Category category;


    @NotBlank
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchant_id", referencedColumnName = "id")
    private User merchant;

    private LocalDateTime createTimestamp;

    private LocalDateTime updateTimestamp;

    public Product() {
    }

    public Product(@NotBlank @Size(max = 50) String product_name,
                   @NotBlank @Size(max = 100) String product_display_name,
                   @NotBlank @Size(max = 250) String product_photoUrl,
                   @NotNull BigDecimal price,
                   @NotNull Integer stockQuantity,
                   @NotNull Integer likes,
                   @NotNull Integer views,
                   @NotBlank Category category,
                   @NotBlank User merchant) {
        this.product_name = product_name;
        this.product_display_name = product_display_name;
        this.product_photoUrl = product_photoUrl;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.likes = likes;
        this.views = views;
        this.category = category;
        this.merchant = merchant;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_display_name() {
        return product_display_name;
    }

    public void setProduct_display_name(String product_display_name) {
        this.product_display_name = product_display_name;
    }

    public String getProduct_photoUrl() {
        return product_photoUrl;
    }

    public void setProduct_photoUrl(String product_photoUrl) {
        this.product_photoUrl = product_photoUrl;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Integer getViews() {
        return views;
    }

    public void setViews(Integer views) {
        this.views = views;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public User getMerchant() {
        return merchant;
    }

    public void setMerchant(User merchant) {
        this.merchant = merchant;
    }

    public LocalDateTime getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(LocalDateTime createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public LocalDateTime getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(LocalDateTime updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + product_name + '\'' +
                ", displayName='" + product_display_name + '\'' +
                ", photoUrl='" + product_photoUrl + '\'' +
                ", price=" + price +
                ", stockQuantity=" + stockQuantity +
                ", likes=" + likes +
                ", views=" + views +
                ", category=" + category +
                ", merchant=" + merchant +
                ", createTimestamp=" + createTimestamp +
                ", updateTimestamp=" + updateTimestamp +
                '}';
    }
}
