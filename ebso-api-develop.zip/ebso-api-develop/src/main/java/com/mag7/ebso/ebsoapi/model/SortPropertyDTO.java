package com.mag7.ebso.ebsoapi.model;

import java.io.Serializable;
import java.util.Objects;

public class SortPropertyDTO implements Serializable {
    private static final long serialVersionUID = 3466438092740865474L;

    private String property;
    private Direction direction = Direction.ASC;

    public SortPropertyDTO(String property, Direction direction) {
        this.property = property;
        this.direction = direction;
    }
    public static enum Direction {
        ASC,
        DESC
    }

    public String getProperty() {
        return property;
    }

    public Direction getDirection() {
        return direction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SortPropertyDTO)) return false;
        SortPropertyDTO that = (SortPropertyDTO) o;
        return getProperty().equals(that.getProperty()) &&
                getDirection() == that.getDirection();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getProperty(), getDirection());
    }

    @Override
    public String toString() {
        return "SortPropertyDTO{" +
                "property='" + property + '\'' +
                ", direction=" + direction +
                '}';
    }
}
