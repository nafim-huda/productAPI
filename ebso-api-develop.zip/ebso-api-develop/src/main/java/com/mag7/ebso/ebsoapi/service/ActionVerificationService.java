package com.mag7.ebso.ebsoapi.service;

import com.mag7.ebso.ebsoapi.entity.ActionVerification;

public interface ActionVerificationService {
    ActionVerification getRegistrationVerification(String username);
    public void confirmUserRegistration(ActionVerification actionVerification);
}
