package com.mag7.ebso.ebsoapi.service.exception;

public class InvalidVerificationCodeException extends ServiceException {
    public InvalidVerificationCodeException() {
        super();
    }

    public InvalidVerificationCodeException(String message) {
        super(message);
    }
    public InvalidVerificationCodeException(String errorCode, String message) {
        super(errorCode, message);
    }

    public InvalidVerificationCodeException(String errorCode, String message, Throwable cause) {
        super(message, message, cause);
    }

}
