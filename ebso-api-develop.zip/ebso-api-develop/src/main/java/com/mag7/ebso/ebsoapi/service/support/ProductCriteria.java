package com.mag7.ebso.ebsoapi.service.support;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Optional;

public class ProductCriteria implements Serializable {
    private static final long serialVersionUID = -7348419499907951764L;

    private Optional<Long> categoryId;
    private Optional<String> product_display_name;
    private Optional<BigDecimal> minimumPrice;
    private Optional<BigDecimal> maximumPrice;
    private Optional<Long> merchantId;

    public ProductCriteria(Optional<Long> categoryId,
                           Optional<String> product_display_name,
                           Optional<BigDecimal> minimumPrice,
                           Optional<BigDecimal> maximumPrice,
                           Optional<Long> merchantId) {
        this.categoryId = categoryId;
        this.product_display_name = product_display_name;
        this.minimumPrice = minimumPrice;
        this.maximumPrice = maximumPrice;
        this.merchantId = merchantId;
    }

    public ProductCriteria() {
    }

    public Optional<Long> getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Optional<Long> categoryId) {
        this.categoryId = categoryId;
    }

    public Optional<String> getProduct_display_name() {
        return product_display_name;
    }

    public void setProduct_display_name(Optional<String> product_display_name) {
        this.product_display_name = product_display_name;
    }

    public Optional<BigDecimal> getMinimumPrice() {
        return minimumPrice;
    }

    public void setMinimumPrice(Optional<BigDecimal> minimumPrice) {
        this.minimumPrice = minimumPrice;
    }

    public Optional<BigDecimal> getMaximumPrice() {
        return maximumPrice;
    }

    public void setMaximumPrice(Optional<BigDecimal> maximumPrice) {
        this.maximumPrice = maximumPrice;
    }

    public Optional<Long> getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Optional<Long> merchantId) {
        this.merchantId = merchantId;
    }

    @Override
    public String toString() {
        return "ProductCriteria{" +
                "categoryId=" + categoryId +
                ", displayName=" + product_display_name +
                ", minimumPrice=" + minimumPrice +
                ", maximumPrice=" + maximumPrice +
                ", merchantId=" + merchantId +
                '}';
    }
}
