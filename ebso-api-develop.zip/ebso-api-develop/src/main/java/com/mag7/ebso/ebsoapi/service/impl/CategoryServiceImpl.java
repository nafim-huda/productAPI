package com.mag7.ebso.ebsoapi.service.impl;

import com.mag7.ebso.ebsoapi.entity.Category;
import com.mag7.ebso.ebsoapi.repository.CategoryRepository;
import com.mag7.ebso.ebsoapi.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    CategoryRepository categoryRepository;

    @Override
    public List<Category> getMainCategories() {
        return categoryRepository.findByParentNull();
    }

    @Override
    public Optional<Category> getCategory(Long id) {
        Optional<Category> optionalCategory = categoryRepository.findById(id);
        optionalCategory.ifPresent(category -> category.getChildren());  //if category is not null, then fech children

        return optionalCategory;
    }
}
