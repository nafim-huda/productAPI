package com.mag7.ebso.ebsoapi.web.controller.advice;

import com.mag7.ebso.ebsoapi.web.controller.response.EbsoResponse;
import com.mag7.ebso.ebsoapi.web.security.token.AppContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * If the response type wrapped inside ResponseEntity is EbsoResponse, add a JWT token to the header section when
 * a new one is generated.  A new JWT token will be generated when the refresh token is still valid and the current one
 * is invalid i.e. it has expired.  This is Spring's aspect oriented programming (AOP) concept.
 */
@ControllerAdvice
public class JwtTokenInjectingAdvice implements ResponseBodyAdvice<EbsoResponse<?>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtTokenInjectingAdvice.class);
    private static final String SUPPORTED_PARAMETER_TYPE_NAME = "?";

    // Gives ypu access to the body of the response in the controller
    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        Type type = returnType.getNestedGenericParameterType();

        if (type instanceof ParameterizedType) {
            type = ((ParameterizedType) type).getActualTypeArguments()[0];
            LOGGER.debug("Raw type:  {}", type.getTypeName());
        }

        //Every controller returns ResponseEntity<?>
        //We want to handle the type EbsoResponse inside ResponseEntity<EbsoResponse> only
        //When there is an error thrown by Spring, ResponseEntity<Map<String, Object>> will be returned.
        //Do a simple check for "?" for the type name which is what it is when is not an instance of Map

        return SUPPORTED_PARAMETER_TYPE_NAME.equals(type.getTypeName());
    }


    @Override
    public EbsoResponse<?> beforeBodyWrite(EbsoResponse<?> ebsoResponse, MethodParameter returnType,
                                           MediaType selectedContentType,
                                           Class<? extends HttpMessageConverter<?>> selectedConverterType,
                                           ServerHttpRequest request,
                                           ServerHttpResponse response) {

        //Read the token from ThreadLocal and if it exists, add it to the EbsoResponse header.
        //The client has the responsibility of replacing old JWT token with the new one.
        String token = AppContextHolder.getContext().getToken();

        if (StringUtils.hasLength(token)) {
            // checks to see if it has a value
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("A new JWT Token was added ");
            }
          //  ebsoResponse.getHeader().setToken(token);
            // goes to the header of EbsoResponse and sets the token to the token passed
            // How you'll see the token property in the JSON response if a new one was generated
        }


        AppContextHolder.clearContext();

        return ebsoResponse;
    }
}
