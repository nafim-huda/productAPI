package com.mag7.ebso.ebsoapi.entity;

public enum CategoryType {
    GOODS,
    SERVICES
}
