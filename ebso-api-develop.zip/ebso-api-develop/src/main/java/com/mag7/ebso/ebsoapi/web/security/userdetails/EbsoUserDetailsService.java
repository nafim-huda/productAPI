package com.mag7.ebso.ebsoapi.web.security.userdetails;

import com.mag7.ebso.ebsoapi.entity.User;
import com.mag7.ebso.ebsoapi.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EbsoUserDetailsService implements UserDetailsService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EbsoUserDetailsService.class);

    @Autowired
    private UserService userService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Look up user '" + username + "'" );
        }
        User user = userService.getUser(username)
                .orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + username));

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("User '" + username + "' was found.  So, return an instance of EbsoUserDetails populated from the User object");
        }

        LocalDateTime lastLoginTImestamp = userService.updateLastLoginTimestamp(user.getUsername());
        user.setLastLoginTimestamp(lastLoginTImestamp);

        List<GrantedAuthority> authorities = user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority(role.getName().name()))
                .collect(Collectors.toList());


        return new EbsoUserDetails(user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getPassword(),
                user.getName().getFirstName(),
                user.getName().getLastName(),
                user.getName().getMiddleName(),
                user.getStatus(),
                user.getPhoneNumber(),
                user.getLastLoginTimestamp(),
                authorities);
    }
}
