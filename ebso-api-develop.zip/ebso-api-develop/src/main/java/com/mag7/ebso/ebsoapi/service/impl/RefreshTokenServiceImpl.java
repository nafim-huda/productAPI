package com.mag7.ebso.ebsoapi.service.impl;

import com.mag7.ebso.ebsoapi.entity.RefreshToken;
import com.mag7.ebso.ebsoapi.repository.RefreshTokenRepository;
import com.mag7.ebso.ebsoapi.service.RefreshTokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class RefreshTokenServiceImpl implements RefreshTokenService {
    @Autowired
    RefreshTokenRepository refreshTokenRepository;

    @Override
    public Optional<RefreshToken> getRefreshTokenDetails(String token) {
        return refreshTokenRepository.findByTokenAndEndTimestampGreaterThan(token, LocalDateTime.now());
    }

    @Override
    public Optional<RefreshToken> getUserRefreshToken(String username) {
        return refreshTokenRepository.findByUsernameAndEndTimestampGreaterThan(username, LocalDateTime.now());

    }

    @Override
    public void saveToken(RefreshToken token) {
        // saves the token to database
        refreshTokenRepository.save(token);
    }

    @Override
    public void invalidateToken(String token) {
        // Invalidates a token
        Optional<RefreshToken> tokenEntity = refreshTokenRepository.findByTokenAndEndTimestampGreaterThan(token, LocalDateTime.now());

        if (tokenEntity.isPresent()) {
            // Sets the end timestamp column to the current time so it can expire immediately
            RefreshToken refreshToken = tokenEntity.get();
            refreshToken.setEndTimestamp(LocalDateTime.now());
            refreshTokenRepository.save(refreshToken);
        }
    }
}
