package com.mag7.ebso.ebsoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbsoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
